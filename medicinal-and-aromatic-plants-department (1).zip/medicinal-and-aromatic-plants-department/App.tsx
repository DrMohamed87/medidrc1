import React, { useState, createContext, useContext, useEffect, ReactNode } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import FloatingIcons from './components/FloatingIcons';
import Tabs from './components/Tabs';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import UnitsPage from './pages/UnitsPage';
import ResearchersPage from './pages/ResearchersPage';
import StatisticsPage from './pages/StatisticsPage';
import { Researcher } from './types';

export type Tab = 'home' | 'about' | 'units' | 'researchers' | 'statistics';
export type Language = 'ar' | 'en';

// --- Language and Translation Setup ---

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: keyof typeof uiStrings) => string;
}

const LanguageContext = createContext<LanguageContextType | null>(null);

const uiStrings = {
  // Tabs
  home: { ar: 'الرئيسية', en: 'Home' },
  about: { ar: 'عن القسم', en: 'About' },
  units: { ar: 'الوحدات', en: 'Units' },
  researchers: { ar: 'الباحثون', en: 'Researchers' },
  statistics: { ar: 'إحصائيات', en: 'Statistics' },
  // General
  departmentName: { ar: 'قسم النباتات الطبية والعطرية', en: 'Dept. of Medicinal & Aromatic Plants' },
  researchCenter: { ar: 'مركز بحوث الصحراء - نحو استدامة الموارد الطبيعية', en: 'Desert Research Center - Towards Sustainable Natural Resources' },
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [lang, setLang] = useState<Language>('ar');

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.body.className = lang === 'ar' ? 'font-ar' : 'font-en';
  }, [lang]);

  const t = (key: keyof typeof uiStrings) => uiStrings[key][lang];

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// --- Helper Functions for Researcher Names ---

export const getTitlePrefix = (titleAr: string, lang: Language): string => {
  if (lang === 'ar') {
    if (titleAr.includes('أستاذ باحث') || titleAr.includes('أستاذ دكتور') || titleAr.startsWith('أستاذ')) {
      return 'أ.د. ';
    }
    if (titleAr.includes('أستاذ مساعد') || titleAr.includes('أستاذ باحث مساعد')) {
      return 'أ.د.م. ';
    }
    if (titleAr.includes('باحث') || titleAr.includes('اخصائي')) {
      return 'د. ';
    }
  }
  // No prefix for English as it's usually already in the name property
  return '';
};

export const getCleanName = (name: string): string => {
  // Removes existing titles from Arabic names to avoid duplication
  return name.replace(/^(أ\.د\.م\.|أ\.د\.م|أ\.د\.\s|أ\.د\/|أ\.د|د\.\s|د\.\/|د\.)\s*/, '');
};

export const getFullNameWithTitle = (researcher: Researcher, lang: Language): string => {
  if (lang === 'en') {
    return researcher.name.en;
  }
  const prefix = getTitlePrefix(researcher.title.ar, 'ar');
  const cleanName = getCleanName(researcher.name.ar);
  return `${prefix}${cleanName}`;
};


// --- Main App Component ---

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const { lang } = useLanguage();

  const renderContent = () => {
    switch (activeTab) {
      case 'about':
        return <AboutPage />;
      case 'units':
        return <UnitsPage />;
      case 'researchers':
        return <ResearchersPage />;
      case 'statistics':
        return <StatisticsPage />;
      case 'home':
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="bg-[#F8FBF6] text-[#37474F]">
      <FloatingIcons />
      <Header />
      <Tabs activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
};

export default App;