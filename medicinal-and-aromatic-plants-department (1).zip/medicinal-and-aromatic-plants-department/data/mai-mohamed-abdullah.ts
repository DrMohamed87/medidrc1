import { Researcher } from '../types';

export const maiMohamedAbdullah: Researcher = {
  name: {
    ar: 'مى محمد احمد عبد الله',
    en: 'Mai Mohamed Ahmed Abdullah',
  },
  title: {
    ar: 'اخصائى صيدلى – الوحدة: المنتجات الطبيعية ؛ القسم: النباتات الطبية والعطرية ؛الشعبة: البيئة وزراعات المناطق الجافة',
    en: 'Pharmacist Specialist - Unit: Natural Products; Department: Medicinal and Aromatic Plants; Division: Environment and Arid Lands Cultivation',
  },
  contact: {
    emails: ['dr.maimohamed87@gmail.com'],
    phones: ['01067011552'],
    address: {
      ar: '',
      en: '',
    },
  },
  education: [
    {
      ar: 'ماجستير العلوم الطبية البيئية – جامعة عين شمس. تاريخ الحصول على درجة الماجستير: 2018/9/24. عنوان رسالة الماجستير: دراسة على المكونات الفعالة والتأثير البيولوجي لنبات تكاييت جبل (تريومفيتا فلافيسنس)',
      en: 'M.Sc. in Environmental Medical Sciences - Ain Shams University. Date of award: 24/9/2018. Thesis title: A study on the active ingredients and biological effect of Triumfetta flavissence',
    },
    {
      ar: 'بكالوريوس العلوم الصيدلية – جامعة القاهرة. تاريخ الحصول على درجة البكالوريوس: 2011/7/26',
      en: 'B.Sc. in Pharmaceutical Sciences - Cairo University. Date of award: 26/7/2011',
    },
  ],
  careerProgression: [
    {
      ar: 'اخصائى صيدلى – الوحدة: المنتجات الطبيعية ؛ القسم: النباتات الطبية والعطرية ؛الشعبة: البيئة وزراعات المناطق الجافة',
      en: 'Pharmacist Specialist - Unit: Natural Products; Department: Medicinal and Aromatic Plants; Division: Environment and Arid Lands Cultivation',
    },
  ],
  publishedPapers: [
    {
      ar: 'Ismail Y, Fahmy DM, Ghattas MH, Ahmed MM, Zehry W, Saleh SM and Abo-elmatty DM (2022), Integrating experimental model, LC-MS/MS chemical analysis, and systems biology approach to investigate the possible antidiabetic effect and mechanisms of Matricaria aurea (Golden Chamomile) in type 2 diabetes mellitus. Front. Pharmacol. 13:924478. doi: 10.3389/fphar.2022.924478',
      en: 'Ismail Y, Fahmy DM, Ghattas MH, Ahmed MM, Zehry W, Saleh SM and Abo-elmatty DM (2022), Integrating experimental model, LC-MS/MS chemical analysis, and systems biology approach to investigate the possible antidiabetic effect and mechanisms of Matricaria aurea (Golden Chamomile) in type 2 diabetes mellitus. Front. Pharmacol. 13:924478. doi: 10.3389/fphar.2022.924478',
    },
  ],
  scientificTheses: [],
  otherScientificPubs: [
    {
      ar: 'اللغات: العربية (اللغة الأم) ، الإنجليزية (بطلاقة).',
      en: 'Languages: Arabic (mother tongue), English (fluent).',
    },
    {
      ar: 'مايكروسوفت أوفيس (وورد ، باوربوينت ، إكسل).',
      en: 'Microsoft Office (Word, PowerPoint, Excel).',
    },
  ],
  projectsAndPrograms: [],
  conferencesAndWorkshops: [],
};
