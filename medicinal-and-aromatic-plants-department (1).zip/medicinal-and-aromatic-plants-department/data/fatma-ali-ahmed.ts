import { Researcher } from '../types';

export const fatmaAliAhmed: Researcher = {
  name: {
    ar: 'فاطمة على أحمد على',
    en: 'Fatma Ali Ahmed Ali',
  },
  title: {
    ar: 'رئيس شعبة البيئة وزراعات المناطق الجافة الأسبق وأستاذ باحث كيمياء النبات المتفرغ بوحدة كيمياء النبات بقسم النباتات الطبية والعطرية بشعبة البيئة وزراعات المناطق الجافة – مركز بحوث الصحراء – وزارة الزراعة وإستصلاح الأراضى.',
    en: 'Former Head of the Environment and Arid Lands Agriculture Division and full-time Professor of Phytochemistry at the Phytochemistry Unit, Department of Medicinal and Aromatic Plants, Environment and Arid Lands Agriculture Division - Desert Research Center - Ministry of Agriculture and Land Reclamation.',
  },
  contact: {
    emails: ['fatma_drc@yahoo.com'],
    phones: ['01001228771'],
    address: {
      ar: '1 ش متحف المطرية – المطرية - القاهرة',
      en: '1 Museum of Mataria St. – Mataria - Cairo',
    },
  },
  education: [
    {
      ar: 'درجة البكالوريوس فى العلوم تخصص (كيمياء– نبات) - كلية البنات – جامعة عين شمس- مايو 1985.',
      en: 'B.Sc. in Science (Chemistry-Botany) - Faculty of Girls - Ain Shams University - May 1985.',
    },
    {
      ar: 'درجة الماجستير فى العلوم (نبات) من كلية البنات - جامعة عين شمس - 1991 وعنوان الرسالة: ”دراسات بيئية و كيمياء نباتية على نبات كروزوفورا بليكاتا“.',
      en: 'M.Sc. in Science (Botany) from the Faculty of Girls - Ain Shams University - 1991. Thesis title: "Ecological and phytochemical studies on Chrozophora plicata (Vahl) A. Juss."',
    },
    {
      ar: 'درجة دكتوراة الفلسفة فى العلوم (نبات) - كلية البنات - جامعة عين شمس سنة 1995. وعنوان الرسالة: ”دراسات بيئية وكيمياء نباتية على نبات (التمير) إيروديوم“.',
      en: 'Ph.D. in Science (Botany) - Faculty of Girls - Ain Shams University - 1995. Thesis title: "Ecological and phytochemical studies on Erodium arborescens (Desf.) Willd."',
    },
    {
      ar: 'أستاذ باحث مساعد "كيمياء نبات" 3/8/ 2002 – قسم النباتات الطبية والعطرية – شعبة البيئة وزراعات المناطق الجافة – مركز بحوث الصحراء.',
      en: 'Assistant Research Professor "Phytochemistry" 3/8/2002 - Department of Medicinal and Aromatic Plants - Environment and Arid Lands Agriculture Division - Desert Research Center.',
    },
    {
      ar: 'أستاذ باحث "كيمياء النبات" –10/ 7/2005 – قسم النباتات الطبية والعطرية – شعبة البيئة وزراعات المناطق الجافة – مركز بحوث الصحراء.',
      en: 'Research Professor "Phytochemistry" - 10/7/2005 - Department of Medicinal and Aromatic Plants - Environment and Arid Lands Agriculture Division - Desert Research Center.',
    },
  ],
  careerProgression: [
    {
      ar: 'رئيس شعبة البيئة وزراعات المناطق الجافة بمركز بحوث الصحراء من 14 ديسمبر 2016 حتى 16 ديسمبر 2022.',
      en: 'Head of the Environment and Arid Lands Agriculture Division at the Desert Research Center from December 14, 2016, to December 16, 2022.',
    },
    {
      ar: 'نائب رئيس مركز بحوث الصحراء للبحوث والدراسات والمشروعات بالقرار الوزارى للسيد ا.د./ وزير الزراعة وإستصلاح اﻷراضى رقم (1792) لسنة 2013م من 28 نوفمبر 2013م حتى 27 /8/ 2015.',
      en: 'Vice President of the Desert Research Center for Research, Studies, and Projects by ministerial decree No. (1792) of 2013 from November 28, 2013, to August 27, 2015.',
    },
    {
      ar: 'رئيس شعبة البيئة وزراعات المناطق الجافة بمركز بحوث الصحراء بقرار ا.د./ رئيس المركز رقم (117) لسنة 2013 من 1/4/2013م حتى 27 نوفمبر 2013.',
      en: 'Head of the Environment and Arid Lands Agriculture Division at the Desert Research Center by decision No. (117) of 2013 from April 1, 2013, to November 27, 2013.',
    },
    {
      ar: 'رئيس قسم النباتات الطبية والعطرية بشعبة البيئة وزراعات المناطق الجافة بقرار ا.د./ رئيس المركز رقم (336) لسنة 2010م من1/10/2010م إلى31/3/2013م.',
      en: 'Head of the Department of Medicinal and Aromatic Plants, Environment and Arid Lands Agriculture Division, by decision No. (336) of 2010 from October 1, 2010, to March 31, 2013.',
    },
    {
      ar: 'التكليف باﻹشراف على معامل شعبة البيئة وزراعات المناطق الجافة بمجمع المعامل بالمقر الرئيسى لمركز بحوث الصحراء بقرار ا.د./ رئيس المركز رقم (255) لسنة 2006 من 8/10/ 2006 إلى 21/3/2010م.',
      en: 'Assigned to supervise the laboratories of the Environment and Arid Lands Agriculture Division at the main laboratory complex of the Desert Research Center by decision No. (255) of 2006 from October 8, 2006, to March 21, 2010.',
    },
    {
      ar: 'التكليف باﻹشراف على وحدة التحليلات الدقيقة - المعمل المركزى بمجمع المعامل (نشاط وحدة ذات طابع خاص) من أول ديسمبر2006 إلى 21/3/ 2010م.',
      en: 'Assigned to supervise the Micro-Analysis Unit - Central Laboratory at the laboratory complex from December 2006 to March 21, 2010.',
    },
    {
      ar: 'رئيس وحدة كيمياء النبات بقسم النباتات الطبية والعطرية بشعبة البيئة وزراعات المناطق الجافة بمركز بحوث الصحراء بقرار ا.د./ رئيس المركز رقم (105) لسنة 2006 من 2/4/2006 إلى 1/10/2011م.',
      en: 'Head of the Phytochemistry Unit, Department of Medicinal and Aromatic Plants, Environment and Arid Lands Agriculture Division, by decision No. (105) of 2006 from April 2, 2006, to October 1, 2011.',
    },
    {
      ar: 'الترقية إلى درجة أستاذ باحث فى مجال كيمياء النبات- وحدة كيمياء النبات- قسم النباتات الطبية والعطرية- شعبة البيئة وزراعات المناطق الجافة - مركز بحوث الصحراء منذ 10/7/2005 حتى تاريخه.',
      en: 'Promoted to Research Professor in Phytochemistry - Phytochemistry Unit - Department of Medicinal and Aromatic Plants - Environment and Arid Lands Agriculture Division - Desert Research Center since July 10, 2005.',
    },
    {
      ar: 'الترقية إلى درجة أستاذ باحث مساعد - وحدة كيمياء النبات - قسم النباتات الطبية والعطرية - شعبة البيئة وزراعات المناطق الجافة - مركز بحوث الصحراء من 20/6/2000 إلى 10/7/2005م .',
      en: 'Promoted to Assistant Research Professor - Phytochemistry Unit - Department of Medicinal and Aromatic Plants - Environment and Arid Lands Agriculture Division - Desert Research Center from June 20, 2000, to July 10, 2005.',
    },
    {
      ar: 'التعيين بدرجة باحث- وحدة كيمياء النبات - قسم النباتات الطبية والعطرية - شعبة البيئة وزراعات المناطق الجافة - مركز بحوث الصحراء من 25/3/1995 إلى 20/6/2000.',
      en: 'Appointed as a Researcher - Phytochemistry Unit - Department of Medicinal and Aromatic Plants - Environment and Arid Lands Agriculture Division - Desert Research Center from March 25, 1995, to June 20, 2000.',
    },
    {
      ar: 'التعيين بدرجة باحث مساعد - وحدة كيمياء النبات - قسم النباتات الطبية والعطرية - شعبة البيئة وزراعات المناطق الجافة - مركز بحوث الصحراء من 26/12/1993 إلى 25/3/1995.',
      en: 'Appointed as an Assistant Researcher - Phytochemistry Unit - Department of Medicinal and Aromatic Plants - Environment and Arid Lands Agriculture Division - Desert Research Center from December 26, 1993, to March 25, 1995.',
    },
    {
      ar: 'مساعد باحث - وحدة كيمياء النبات - قسم النباتات الطبية والعطرية - شعبة البيئة وزراعات المناطق الجافة - مركز بحوث الصحراء من 1/11/1993 حتى 26/12/1993.',
      en: 'Research Assistant - Phytochemistry Unit - Department of Medicinal and Aromatic Plants - Environment and Arid Lands Agriculture Division - Desert Research Center from November 1, 1993, to December 26, 1993.',
    },
  ],
  scientificTheses: [
    {
      ar: 'اﻹشراف على العديد من رسائل الماجستير والدكتوراة بمختلف الجامعات المصرية (حوالى 40 رسالة).',
      en: 'Supervision of many Master\'s and Ph.D. theses in various Egyptian universities (about 40 theses).',
    },
  ],
  publishedPapers: [
    {
      ar: 'Ghandour, Moustafa M., et al. (2025). Potential of Salicornia fruticosa as a forage in Egypt...',
      en: 'Ghandour, Moustafa M., et al. (2025). Potential of Salicornia fruticosa as a forage in Egypt...',
    },
    {
      ar: 'Youssif, Y.M., et al. (2024). Applying UPLC-QTOF-MS/MS to profile the phytochemical constituents...',
      en: 'Youssif, Y.M., et al. (2024). Applying UPLC-QTOF-MS/MS to profile the phytochemical constituents...',
    },
  ],
  projectsAndPrograms: [
    {
      ar: 'Leadership and member of phytochemistry teamwork of the project (The development and optimization of halophyte – based farming systems in salt affected Mediterranean soils (HaloFarms). Funded by Academy of Scientific Research and Technology (ASRT), Ministry of Scientific Research (2019-2025).',
      en: 'Leadership and member of phytochemistry teamwork of the project (The development and optimization of halophyte – based farming systems in salt affected Mediterranean soils (HaloFarms). Funded by Academy of Scientific Research and Technology (ASRT), Ministry of Scientific Research (2019-2025).',
    },
    {
      ar: 'PI of the project (Maximizing the use of succulants plants for development of populations in Matrouh Governorate) Funded by Academy of Scientific Research and Technology (ASRT), (2020-2023).',
      en: 'PI of the project (Maximizing the use of succulants plants for development of populations in Matrouh Governorate) Funded by Academy of Scientific Research and Technology (ASRT), (2020-2023).',
    },
  ],
  conferencesAndWorkshops: [
    {
      ar: 'رئيس لجنة مراجعة إحتياجات الشعب البحثية بالمركز من اﻷجهزة العلمية بقرار ا.د./ رئيس المركز رقم (229) لسنة 2014.',
      en: 'Chairman of the committee to review the needs of the research divisions of the center for scientific equipment by decision No. (229) of 2014.',
    },
    {
      ar: 'رئيس اللجنة العليا للبحوث والدراسات بالمركز بقرار ا.د./ رئيس المركز رقم (506) لسنة 2013.',
      en: 'Chairman of the Higher Committee for Research and Studies at the Center by decision No. (506) of 2013.',
    },
  ],
  otherScientificPubs: [
    {
      ar: 'المشاركة فى تأليف فصل فى كتاب دولى تم نشرة بدار النشر سبرينجر نيتشر (Springer Nature) تحت عنوان : History of the Egyptian Desert Gene Bank (EDGB)',
      en: 'Co-author of a chapter in an international book published by Springer Nature titled: History of the Egyptian Desert Gene Bank (EDGB)',
    },
    {
      ar: 'Co-author of the book entitled (Elba Nature Protectorate Encyclopedia), volume (1), 2022...',
      en: 'Co-author of the book entitled (Elba Nature Protectorate Encyclopedia), volume (1), 2022...',
    },
  ],
};
