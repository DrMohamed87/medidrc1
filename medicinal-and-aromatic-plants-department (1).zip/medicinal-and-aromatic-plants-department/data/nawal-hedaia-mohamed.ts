import { Researcher } from '../types';

export const nawalHedaiaMohamed: Researcher = {
  name: {
    ar: 'نوال هداية محمد حسن',
    en: 'Nawal Hedaia Mohamed Hassan',
  },
  title: {
    ar: 'أستاذ باحث مساعد',
    en: 'Assistant Professor',
  },
  contact: {
    emails: ['nawal_h70@yahoo.com', 'Nawalhedaya1@gmail.com'],
    phones: ['0110455589'],
    address: { ar: 'غير متوفر', en: 'Not Available' },
  },
  education: [
    {
      ar: 'دكتوراه، ديسمبر 2002: قسم الكيمياء، كلية العلوم، جامعة عين شمس، القاهرة، مصر.',
      en: 'Ph.D., December 2002: Chemistry Department, Faculty of Science, Ain Shams University, Cairo, Egypt.',
    },
    {
      ar: 'ماجستير، ديسمبر 1998: قسم الكيمياء، كلية العلوم، جامعة عين شمس، القاهرة، مصر.',
      en: 'M.Sc., December 1998: Chemistry Department, Faculty of Science, Ain Shams University, Cairo, Egypt.',
    },
    {
      ar: 'بكالوريوس، يونيو 1991: كيمياء وكيمياء حيوية، كلية العلوم، جامعة عين شمس.',
      en: 'B. Sc., June 1991: Chemistry and Biochemistry, Faculty of Science, Ain Shams University',
    },
  ],
  careerProgression: [
    { ar: 'أستاذ باحث مساعد, وحدة كيمياء النبات، قسم النباتات الطبية والعطرية، شعبة البيئة وزراعات المناطق الجافة.', en: 'Assistant Professor, Plant Chemistry Unit, Department of Medicinal and Aromatic Plants, Division of Environment and Arid Lands Cultivation.' },
    { ar: '1993-2000: أخصائي كيمياء في قسم النباتات العطرية والطبية، مركز بحوث الصحراء، القاهرة، مصر.', en: '1993-2000: Chemistry Specialist in Aromatic and Medicinal Plant Depart, Desert Res. Center. Cairo, Egypt' },
    { ar: '2000-2002: باحث مساعد، قسم النباتات العطرية والطبية، مركز بحوث الصحراء، القاهرة، مصر.', en: '2000-2002: Assistant Researcher, Aromatic and Medicinal Plant Department, Desert Research Center. Cairo, Egypt' },
    { ar: '2002-حتى الآن: باحث في البيولوجيا والكيمياء النباتية، قسم النباتات العطرية والطبية، مركز بحوث الصحراء، القاهرة، مصر.', en: '2002-Present: Researcher of Biology and Phytochemistry, Aromatic and Medicinal Plant Department, Desert Research Center. Cairo, Egypt' },
    { ar: '2010: أستاذ مشارك في الكيمياء النباتية، قسم النباتات العطرية والطبية، مركز بحوث الصحراء، القاهرة.', en: '2010: Associate Prof. of phytochemistry, Aromatic and Medicinal Plant Department, Desert Research Center. Cairo' },
    { ar: '2010 حتى 2021: أستاذ مشارك في الكيمياء العضوية، كلية العلوم، قسم البنات، جامعة جازان، جازان، المملكة العربية السعودية.', en: '2010 till 2021: Associate Prof. of organic chemistry, Fac. of Science, Girls Section, Jazan Univ. Jazan, KSA' },
  ],
  scientificTheses: [
    {
      ar: 'رسالة دكتوراه بعنوان "دراسات فيتوكيميائية وبيولوجية على نبات العليق الحقلي".',
      en: 'The Thesis entitled “Phytochemical and Biological studies on Convolvulus arvensis L.”',
    },
    {
      ar: 'رسالة ماجستير بعنوان "دراسات فيتوكيميائية على Diplotaxis acris".',
      en: 'The Thesis entitled “Phytochemical studies on Diplotaxis acris”',
    },
  ],
  publishedPapers: [
    { ar: 'Amani S. A; Abd El-Gawad M. R; Emad El-Din M. A. and Nawal H. M.(2002):Phytochemical and biological studies on Convolvulus arvensis L. XXVIII Conference of Pharmaceutical Science, EgyptPp 52,', en: 'Amani S. A; Abd El-Gawad M. R; Emad El-Din M. A. and Nawal H. M.(2002):Phytochemical and biological studies on Convolvulus arvensis L. XXVIII Conference of Pharmaceutical Science, EgyptPp 52,' },
    { ar: 'Amani S. Awaad; K. F. Amer; and N. H. Hassan (1999) Phytochemical, investigation, carbohydrate, protein, lipid contents and antimicrobial activity of Diplotaxisacris”. Bull. Fac. Pharm., Cairo Univ., Vol. 37(1), 81- 87.', en: 'Amani S. Awaad; K. F. Amer; and N. H. Hassan (1999) Phytochemical, investigation, carbohydrate, protein, lipid contents and antimicrobial activity of Diplotaxisacris”. Bull. Fac. Pharm., Cairo Univ., Vol. 37(1), 81- 87.' },
    { ar: 'N. H. El-Sayed; N. H. Mohamed; E. A. Soher; K. H. Mohamed and T. J. Mabry(1999): Flavonoids and other constituents from Diplotaxis acris ( Cruciferae) Rev. Latinoamer. Quim. Vol. 27(1), 1-4.', en: 'N. H. El-Sayed; N. H. Mohamed; E. A. Soher; K. H. Mohamed and T. J. Mabry(1999): Flavonoids and other constituents from Diplotaxis acris ( Cruciferae) Rev. Latinoamer. Quim. Vol. 27(1), 1-4.' },
    { ar: 'Awaad, Amani, S.; Nawal, H. Mohamed and Khadiga, F, Aamer (2004): Alkaloids, some constituents and antimicrobial activity of Convolvulus arvensis L. Egyptian J. Desert Res., 54 (2), 315-326.', en: 'Awaad, Amani, S.; Nawal, H. Mohamed and Khadiga, F, Aamer (2004): Alkaloids, some constituents and antimicrobial activity of Convolvulus arvensis L. Egyptian J. Desert Res., 54 (2), 315-326.' },
    { ar: 'Emad, M. Ata; Mohamed, A. A; Nawal, H. M and Gamal, A. S. (2005): Studies on some active constituents and antiulcerogenic activity of Cordiasinensis Lam. (In vivo and In vitro Culture). Bull. Fac. Pharm. Cairo Univ. Vol. 43 (3): 205- 215.', en: 'Emad, M. Ata; Mohamed, A. A; Nawal, H. M and Gamal, A. S. (2005): Studies on some active constituents and antiulcerogenic activity of Cordiasinensis Lam. (In vivo and In vitro Culture). Bull. Fac. Pharm. Cairo Univ. Vol. 43 (3): 205- 215.' },
    { ar: 'Nawal, H. Mohamed; Amani, S. Awaad; D. J. Maitland and G. A. Soliman (2006): Pharmacological activity of alcohol extract and some isolated flavonoids from Desmostachiabipennata L. Rec. Nat. Prod2:3 76-82.', en: 'Nawal, H. Mohamed; Amani, S. Awaad; D. J. Maitland and G. A. Soliman (2006): Pharmacological activity of alcohol extract and some isolated flavonoids from Desmostachiabipennata L. Rec. Nat. Prod2:3 76-82.' },
    { ar: 'Attia, H. Atta; Nawal, H. Mohamed; Soad, M. Nasr and Samar, M. Mouneir (2007): Phytochemical and pharmacological studies on Convolvulus fatmensisKtze. J. of natural remedies, Vol. 7, (1), 91-101.', en: 'Attia, H. Atta; Nawal, H. Mohamed; Soad, M. Nasr and Samar, M. Mouneir (2007): Phytochemical and pharmacological studies on Convolvulus fatmensisKtze. J. of natural remedies, Vol. 7, (1), 91-101.' },
    { ar: 'Nawal H. Mohamed and Atta E. Mahrous(2009): Chemical constituents ofDescurainiasophia L. and Its biological activity. Rec. Nat. Prod. 3:1 58-67', en: 'Nawal H. Mohamed and Atta E. Mahrous(2009): Chemical constituents ofDescurainiasophia L. and Its biological activity. Rec. Nat. Prod. 3:1 58-67' },
    { ar: 'M.E. Ahlam; E.M. Atta; A.S. Gamal; M. Jaspars;  H. M. Nawal and E. T. Hala (2009): Phytochemical and Biological Studies of SisymbriumirioL.growing in Egypt. J. Saudi Chem. Soc., Vol. 12 (4): pp. 477-488.', en: 'M.E. Ahlam; E.M. Atta; A.S. Gamal; M. Jaspars;  H. M. Nawal and E. T. Hala (2009): Phytochemical and Biological Studies of SisymbriumirioL.growing in Egypt. J. Saudi Chem. Soc., Vol. 12 (4): pp. 477-488.' },
    { ar: 'Nawal, H. Mohamed and Abeer, M. Elhadidy(2009): Studies of Biologically Active Constituents of VerbascumeremobiumMurb. Resistance and its Inducing Against some Disease of Cucumber RPMP - Ethnomedicine: Source & Mechanism I Vol. 27145-163', en: 'Nawal, H. Mohamed and Abeer, M. Elhadidy(2009): Studies of Biologically Active Constituents of VerbascumeremobiumMurb. Resistance and its Inducing Against some Disease of Cucumber RPMP - Ethnomedicine: Source & Mechanism I Vol. 27145-163' },
    { ar: 'Nawal, H. Mohamed(2009):Anticancer Activity of Marrubiumalysson L. andIts Phenolic Constituents. RPMP - Ethnomedicine: Source & Mechanism I Vol. 27 191-199.', en: 'Nawal, H. Mohamed(2009):Anticancer Activity of Marrubiumalysson L. andIts Phenolic Constituents. RPMP - Ethnomedicine: Source & Mechanism I Vol. 27 191-199.' },
    { ar: 'Nawal, H. Mohamed and Atta, E.M (2010): A Comparative Phytochemicsl and Biological Studies on Some Plants Belonging to Family Cruciferae. RPMP— Ethnomedicine: Source & Mechanism II. Vol. 28, 293-302.', en: 'Nawal, H. Mohamed and Atta, E.M (2010): A Comparative Phytochemicsl and Biological Studies on Some Plants Belonging to Family Cruciferae. RPMP— Ethnomedicine: Source & Mechanism II. Vol. 28, 293-302.' },
    { ar: 'Atta, E. M; A.A.-H. Abdel-Rahman; Jaspars, M; Nawal, H. Mohamed and A. R. Hassan.New flavonoid glycoside and pharmacological activities of PteranthusdichotomusForssk. Records of Natural Products, 7:2 (2013): 69-79.', en: 'Atta, E. M; A.A.-H. Abdel-Rahman; Jaspars, M; Nawal, H. Mohamed and A. R. Hassan.New flavonoid glycoside and pharmacological activities of PteranthusdichotomusForssk. Records of Natural Products, 7:2 (2013): 69-79.' },
    { ar: 'Nawal, H. Mohamed and Atta, E. M. (2013): Cytotoxic and antioxidant activity of Marobiumvulgare and its flavonoid constituents. 2ndInternationalconference on chemical, environmental and biological sciences (ICCEBS’ 2013).40-42.', en: 'Nawal, H. Mohamed and Atta, E. M. (2013): Cytotoxic and antioxidant activity of Marobiumvulgare and its flavonoid constituents. 2ndInternationalconference on chemical, environmental and biological sciences (ICCEBS’ 2013).40-42.' },
    { ar: 'Emad M. Atta[a,b]*, Nawal H. Mohamed[c,d] and Ahmed A. M. Abdelgawad[d]( 2017) ANTIOXIDANTS: AN OVERVIEW ON THE NATURAL AND SYNTHETIC TYPES  Eur. Chem. Bull. 2017, 6(8), 365-375', en: 'Emad M. Atta[a,b]*, Nawal H. Mohamed[c,d] and Ahmed A. M. Abdelgawad[d]( 2017) ANTIOXIDANTS: AN OVERVIEW ON THE NATURAL AND SYNTHETIC TYPES  Eur. Chem. Bull. 2017, 6(8), 365-375' },
    { ar: 'Mona N. El Hazek,* Nawal H. Mohamed  and Azza A. Gabr ( 2019)  Potash Breakdown of Poly-mineralized Niobium-Tantalum- lanthanides Ore Material AJAC  10,103- 111.', en: 'Mona N. El Hazek,* Nawal H. Mohamed  and Azza A. Gabr ( 2019)  Potash Breakdown of Poly-mineralized Niobium-Tantalum- lanthanides Ore Material AJAC  10,103- 111.' },
    { ar: 'Nawal H. Mohamed ,, Ahmed A. M. Abdelgawad, and Taha A. I. El Bassossy Chemical and biological investigation of the aerial parts of Aizoon canariense L Eur. Chem. Bull. 2023,12(10), 2857-2875', en: 'Nawal H. Mohamed ,, Ahmed A. M. Abdelgawad, and Taha A. I. El Bassossy Chemical and biological investigation of the aerial parts of Aizoon canariense L Eur. Chem. Bull. 2023,12(10), 2857-2875' },
  ],
  conferencesAndWorkshops: [
    { ar: '2024: حضور المؤتمر الدولي لمكتب براءات الاختراع في مجال الزراعة والأمن الغذائي، المركز القومي للبحوث.', en: '2024: Attendance in International conference of the patent contact office in the field of Agriculture and food security, National Research center.' },
    { ar: '2023: حضور مؤتمر عالم التكنولوجيا الحيوية 2، جامعة النيل.', en: '2023: Attendance in Biotech world conference 2, Nile university' },
    { ar: '2013: المشاركة في المؤتمر الدولي الثاني للعلوم الكيميائية والبيئية والبيولوجية (ICCEBS’ 2013). دبي (الإمارات العربية المتحدة)، 17-18 مارس.', en: '2013: Participation in 2nd International conference on chemical, environmental and biological sciences (ICCEBS’ 2013). Dubai (UAE), March 17-18' },
    { ar: '2012: حضور يوم البحث الطبي الذي نظمته كلية الطب بجامعة جازان.', en: '2012: Attendance in Medical research day organized by faculty of medicine Jazan university.' },
    { ar: '2011: حضور المؤتمر الدولي الرابع للكيمياء، كلية العلوم، جامعة الملك سعود، المملكة العربية السعودية.', en: '2011: Attendance in forth International Chemistry conference collage of science, King Saud University KSA.' },
    { ar: '2009: حضور المؤتمر الدولي الرابع لشعبة الصناعات الصيدلانية والدوائية. المركز القومي للبحوث. تحت شعار "البحث والتطوير في الأدوية: التحديات الحالية".', en: '2009: Attendance in The 4th International Conference of Pharmaceutical and Drug Industries Division. National Research Center. Under the theme “Research and Development in Drugs: Current Challenges”' },
    { ar: '2007: دورة تدريبية في كلية أبردين، اسكتلندا، مقدمة في اللغة الإنجليزية للحوسبة.', en: '2007: Training course at Aberdeen College, Scotland, Introduction to English for computing.' },
    { ar: '2005: دورة توفل في الأمد إيست، القاهرة، مصر.', en: '2005: TOEFL course at the Amid East, Cairo, Egypt.' },
    { ar: '2005: دورة تدريبية في المركز القومي للبحوث، (عزل المركبات النشطة بيولوجياً من النباتات المحلية).', en: '2005: Training course at National Research Center, (Isolation of biologically active compounds from native plants).' },
    { ar: '2005: حضور المؤتمر الدولي الثاني لشعبة الصناعات الصيدلانية والدوائية. المركز القومي للبحوث. تحت شعار "البحوث التطبيقية لصناعة الأدوية".', en: '2005: Attendance in the Second International Conference of Pharmaceutical and Drug Industries Division. National Research Center.Under the theme of “Applied Research for Drug Industry” National Research Center.' },
    { ar: '2004: عضو متعاون في المؤتمر السابع والعشرون للعلوم الصيدلانية.', en: '2004: Co-operation member in the XXVIIII Conference of Pharmaceutical Science.' },
    { ar: '2004: دورة تدريبية في المركز الإقليمي للنظائر المشعة للدول العربية.', en: '2004: Training course at Middle Eastern Regional Radioisotope Center for the Arab Countries.' },
    { ar: '2002: عضو متعاون في المؤتمر الثامن والعشرون للعلوم الصيدلانية.', en: '2002: Co-operation member in the XXVIII Conference of Pharmaceutical Science.' },
  ],
  projectsAndPrograms: [
    { ar: '2002-2008: عضو في فريق البحث لمشروع "تنمية الساحل الشمالي الغربي لمصر".', en: '2002-2008: Member in the research team of the project “Development of the Northern West coast of Egypt”' },
    { ar: '1993-1995: عضو في فريق البحث لمشروع "مسح النباتات الطبية في صحاري سيناء والساحل الشمالي الغربي للبحر الأبيض المتوسط".', en: '1993-1995: Member in the research team of the project “ Survey of Medicinal Plants in the deserts of Sinai and Western Northern coast of the Mediterranean Sea”' },
  ],
  otherScientificPubs: [
    { ar: 'إشراف على عدد [1] رسائل ماجستير.', en: 'Supervision of [1] Master\'s theses.' },
    { ar: 'المهارات: اللغة الإنجليزية: تحدث وكتابة جيدة.', en: 'Skills: English language good speaking and writing' },
    { ar: 'المهارات: دورة توفل من جامعة عين شمس. درجة (500).', en: 'Skills: TOEFL course from Ain Shams Univ. Score (500)' },
    { ar: 'المهارات: دورة توفل في الأمد إيست، القاهرة، مصر.', en: 'Skills: TOEFL course at the Amid East, Cairo, Egypt.' },
    { ar: 'المهارات: مهارات تصميم محتوى التعليم.', en: 'Skills: Skills of instruction content Design.' },
    { ar: 'المهارات: مهارات استخدام الفصول الافتراضية.', en: 'Skills: Skills of using virtual Classes.' },
    { ar: 'المهارات: استخدام تكنولوجيا الويب في التعليم الإلكتروني والتعلم عن بعد.', en: 'Skills: Using Web Technology in E- learning and Distance learning.' },
    { ar: 'المهارات: استراتيجيات جديدة في التدريس والتعلم.', en: 'Skills: New strategies in teaching and learning.' },
  ],
};
