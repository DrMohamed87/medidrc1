import { Researcher } from '../types';

export const youssraEssam: Researcher = {
  name: {
    ar: 'يسرا عصام مصطفى عبد الرحمن',
    en: 'Youssra Essam Mostafa Abd El-Rahman',
  },
  title: {
    ar: 'أخصائى بوحدة المنتجات الطبيعية قسم النباتات الطبية و العطرية',
    en: 'Specialist at the Natural Products Unit, Department of Medicinal and Aromatic Plants',
  },
  contact: {
    emails: ['YoussraEssam@gmail.com'],
    phones: ['01021546060'],
    address: {
      ar: '',
      en: '',
    },
  },
  education: [
    {
      ar: 'ماجستير. معهد البيئه. تاريخ المنح: 14 يناير 2018. عنوان الرسالة: دراسات بيولوجيه وفيتوكيميائية على بعض الطحالب النافعه المعزولة من واحة سيوة',
      en: 'M.Sc. Institute of Environment. Date of award: January 14, 2018. Thesis title: Biological and phytochemical studies on some beneficial algae isolated from Siwa Oasis',
    },
  ],
  careerProgression: [
    {
      ar: 'أخصائى تحاليل طبية',
      en: 'Medical analysis specialist',
    },
    {
      ar: 'أخصائى بمشروع بحثى بوحدة ذات طابع خاص كلية العلوم جامعة عين شمس',
      en: 'Specialist in a research project at a special unit, Faculty of Science, Ain Shams University',
    },
  ],
  publishedPapers: [
    {
      ar: 'بحث واحد منشور فى مجلة معهد البيئة',
      en: 'One paper published in the Journal of the Institute of Environment',
    },
  ],
  scientificTheses: [],
  conferencesAndWorkshops: [
    {
      ar: 'تم حضور العديد من السيمينارات بالقسم والشعبة والمناقاشات بالجامعة',
      en: 'Attended many seminars in the department and division and discussions at the university',
    },
  ],
  otherScientificPubs: [
    {
        ar: 'تم اجتياز اختبار تويفل للغة الانجليزية لاستكمال متطلبات التسجيل للماجستير',
        en: 'Passed the TOEFL test for Master\'s registration requirements',
    }
  ]
};
