import { Researcher } from '../types';

export const abdElRaheimDonia: Researcher = {
  name: {
    ar: 'عبد الرحيم محمد احمد دنيا',
    en: 'Abd El Raheim Mohamed Ahmed Donia',
  },
  title: {
    ar: 'استاذ مساعد – وحدة المنتجات الطبيعية بقسم النباتات الطبية والعطرية- مركز بحوث الصحراء -القاهرة-جمهورية مصر العربية',
    en: 'Assistant Professor - Natural Products Unit, Department of Medicinal and Aromatic Plants - Desert Research Center - Cairo, Arab Republic of Egypt',
  },
  contact: {
    emails: ['donia22276@yahoo.com', 'donia_2222000@yahoo.com'],
    phones: ['00201154347322', '00201091153411'],
    address: {
      ar: 'ق 1000 مج8 - الاسكان العائلي ( حى الجولف) مدينة الشروق -القاهرة-مصر',
      en: 'Q 1000, Group 8 - Family Housing (Golf District), El Shorouk City - Cairo, Egypt',
    },
    links: [
      {
        name: 'Google Scholar',
        url: 'https://scholar.google.com/citations?hl=ar&user=LV16lYsAAAAJ',
      },
      {
        name: 'ORCID',
        url: 'https://orcid.org/0000-0002-4792-4679',
      },
      {
        name: 'Scopus',
        url: 'https://www.scopus.com/authid/detail.uri?authorId=37080479300',
      },
    ],
  },
  education: [
    {
      ar: 'بكالوريوس العلوم بتقدير ممتاز مع مرتبة الشرف (دور مايو 1998م) -كلية العلوم -جامعة المنوفية -جمهورية مصر العربية.',
      en: 'B.Sc. in Science with excellent grade with honors (May 1998) - Faculty of Science - Menoufia University - Arab Republic of Egypt.',
    },
    {
      ar: 'ماجستير في العلوم (كيمياء عضوية) قسم الكيمياء كلية العلوم جامعة عين شمس القاهرة-جمهورية مصر العربية 2003. تحت عنوان: "تأثير الجفاف والملوحة علي القيمة الغذائية لنبات القطف الانتفورمس والبرسوبس الشيلي"',
      en: 'M.Sc. in Science (Organic Chemistry), Department of Chemistry, Faculty of Science, Ain Shams University, Cairo - Arab Republic of Egypt 2003. Thesis: "Effect of Salinity and Drought on the Nutritive Value of Atriplex lentiformis And Prosopis chilensis."',
    },
    {
      ar: 'دكتوراه الفلسفة في العلوم (كيمياء) (2006) -كلية العلوم -جامعة عين شمس-جمهورية مصر العربية. تحت عنوان: "دراسات على بعض النواتج الطبيعية التي تؤثر على استخدام نبات القطف اللانتفورمس في تغذية الحيوان"',
      en: 'Ph.D. in Science (Chemistry) (2006) - Faculty of Science - Ain Shams University - Arab Republic of Egypt. Thesis: "Studies on Some Natural Products Affecting the Use of Atriplex lentiformis In Animal Nutrition"',
    },
  ],
  careerProgression: [
    {
      ar: 'رئيس وحدة المنتجات الطبيعية بقسم النباتات الطبية والعطرية – مركز بحوث الصحراء-القاهرة (2020 -حتى الان).',
      en: 'Head of the Natural Products Unit, Department of Medicinal and Aromatic Plants - Desert Research Center - Cairo (2020 - present).',
    },
    {
      ar: 'أستاذ مساعد بقسم النباتات الطبية والعطرية – مركز بحوث الصحراء-القاهرة-جمهورية مصر العربية (من 2018 م -حتى الآن).',
      en: 'Assistant Professor, Department of Medicinal and Aromatic Plants - Desert Research Center - Cairo, Arab Republic of Egypt (from 2018 - present).',
    },
    {
      ar: 'استاذ مشارك-قسم العقاقير-كلية الصيدلة -جامعة سلمان بن عبد العزيز – المملكة العربية السعودية. (مارس 2015 حتى يونيو 2018).',
      en: 'Associate Professor - Department of Pharmacognosy - College of Pharmacy - Salman bin Abdulaziz University - Kingdom of Saudi Arabia. (March 2015 to June 2018).',
    },
    {
      ar: 'استاذ مساعد-قسم العقاقير-كلية الصيدلة -جامعة سلمان بن عبد العزيز – المملكة العربية السعودية. (من 2009 حتى مارس 2015).',
      en: 'Assistant Professor - Department of Pharmacognosy - College of Pharmacy - Salman bin Abdulaziz University - Kingdom of Saudi Arabia. (from 2009 to March 2015).',
    },
    {
      ar: 'دكتور زائر بالولايات المتحدة الأمريكية بجامعة مساتشوستس University of Massachusetts, Amherst, USA. في الفترة من 9/7/2008 إلى 8/4/2009م',
      en: 'Visiting Doctor at the University of Massachusetts, Amherst, USA. from 7/9/2008 to 4/8/2009.',
    },
    {
      ar: 'رئيس وحدة المنتجات الطبيعية بقسم النباتات الطبية والعطرية – مركز بحوث الصحراء-القاهرة (2006-2007)',
      en: 'Head of the Natural Products Unit, Department of Medicinal and Aromatic Plants - Desert Research Center - Cairo (2006-2007)',
    },
    {
      ar: 'باحث مساعد بقسم البيئة النباتية والمراعي – مركز بحوث الصحراء-القاهرة -جمهورية مصر العربية في الفترة من 2003-2006.',
      en: 'Assistant Researcher, Department of Plant Ecology and Rangelands - Desert Research Center - Cairo - Arab Republic of Egypt from 2003-2006.',
    },
    {
      ar: 'مساعد باحث بقسم البيئة النباتية والمراعي – مركز بحوث الصحراء-القاهرة -جمهورية مصر العربية في الفترة من 2000-2003.',
      en: 'Research Assistant, Department of Plant Ecology and Rangelands - Desert Research Center - Cairo - Arab Republic of Egypt from 2000-2003.',
    },
  ],
  scientificTheses: [
    {
      ar: 'مشرف على رسالة الدكتوراة الخاصة بالطالبة / يسرا عصام مصطفى عبد الرحمن تحت عنوان: دراسات فيتوكيميائية والنشاط المضاد لإلتهابات الفم لبعض النباتات الطبية المصرية- جامعة الازهر.',
      en: 'Supervisor of the Ph.D. thesis of student / Yosra Essam Mustafa Abdel Rahman titled: Phytochemical studies and anti-oral inflammatory activity of some Egyptian medicinal plants - Al-Azhar University.',
    },
    {
      ar: 'مشرف على رسالة الدكتوراة الخاصة بالطالبة / مى محمد عبدالله تحت عنوان: دراسة كيميائية وبيولوجية على بعض انواع جنس الفول وتفرقتهم باستخدام التحليل متعدد المتغيرات- جامعة عين شمس',
      en: 'Supervisor of the Ph.D. thesis of student / Mai Mohamed Abdullah titled: Chemical and biological study on some species of the genus Vicia and their differentiation using multivariate analysis - Ain Shams University',
    },
    {
      ar: 'مشرف على رسالة الماجستير الخاصة بـ الطالبة/ زينب محمد مرسى على- تحت عنوان: دراسات مقارنة على بعض فصائل العائلة الرمرامية التى تنمو على نطاق واسع في مصر- كلية العلوم- جامعة بنها- مصر.',
      en: 'Supervisor of the M.Sc. thesis of student / Zainab Mohamed Morsi Ali - titled: Comparative studies on some species of the Chenopodiaceae family that grow widely in Egypt - Faculty of Science - Benha University - Egypt.',
    },
    {
      ar: 'مشرف على رسالة الماجستير الخاصة بـ الطالب/خالد شريف محمد محمد امين-تحت عنوان : دراسة عقاقيرية لنبات كايلوزياهيكساجينا النامي بجنوب شرق مصر.كلية الصيدلة- جامعة القاهرة- مصر.',
      en: 'Supervisor of the M.Sc. thesis of student / Khaled Sherif Mohamed Mohamed Amin - titled: Pharmacognostic study of Caylusea hexagyna growing in southeastern Egypt. Faculty of Pharmacy - Cairo University - Egypt.',
    },
  ],
  publishedPapers: [
    {
      ar: 'Abd El Raheim M. Donia, et al. (2015) The Potential Anti-inflammatory activity of essential oils of Pituranthos triradiatus and Anthemis deserti in rats.',
      en: 'Abd El Raheim M. Donia, et al. (2015) The Potential Anti-inflammatory activity of essential oils of Pituranthos triradiatus and Anthemis deserti in rats.',
    },
    {
      ar: 'Gamal A. Soliman and Abd El Raheim M. Donia (2015). Antihyperglycemic, antihyperlipidemic and antioxidant effect of Atriplex farinosa and Atriplex nummularia in streptozotocin-induced diabetes in rats.',
      en: 'Gamal A. Soliman and Abd El Raheim M. Donia (2015). Antihyperglycemic, antihyperlipidemic and antioxidant effect of Atriplex farinosa and Atriplex nummularia in streptozotocin-induced diabetes in rats.',
    },
    {
      ar: 'Omer A. Basudan, et al. (2015). Development and Validation of a High-Performance Thin-Layer Chromatographic Method for the Determination of Biomarker β-Amyrin in the Leaves of Different Ficus Species.',
      en: 'Omer A. Basudan, et al. (2015). Development and Validation of a High-Performance Thin-Layer Chromatographic Method for the Determination of Biomarker β-Amyrin in the Leaves of Different Ficus Species.',
    },
    {
      ar: 'Amani S. Awaad, et al. (2016). Novel Anti-ulcerogenic Effects of Total Extract and Isolated Compounds from Cakile arabica.',
      en: 'Amani S. Awaad, et al. (2016). Novel Anti-ulcerogenic Effects of Total Extract and Isolated Compounds from Cakile arabica.',
    },
    {
      ar: 'Abd El Raheim M. Donia, et al. (2016). Evaluation of Antimicrobial Activities of Matricaria recutita, Ricinus Communis and Zygophylum coccineum.',
      en: 'Abd El Raheim M. Donia, et al. (2016). Evaluation of Antimicrobial Activities of Matricaria recutita, Ricinus Communis and Zygophylum coccineum.',
    },
    {
      ar: 'Prawez Alam, et al. (2017). Simultaneous detection and quantification of Biomarker glycosides in different Atriplex species using HPTLC.',
      en: 'Prawez Alam, et al. (2017). Simultaneous detection and quantification of Biomarker glycosides in different Atriplex species using HPTLC.',
    },
    {
      ar: 'Abd El Raheim. M. Donia (2016). Phytochemical and pharmacological studies on Scorzonera alexandrina Boiss.',
      en: 'Abd El Raheim. M. Donia (2016). Phytochemical and pharmacological studies on Scorzonera alexandrina Boiss.',
    },
    {
      ar: 'Eman Ramadan Elsharkawy, et al. (2017). Comparative Study of Antioxidant and Anticancer Activity of Thuja orientalis Growing in Egypt and Saudi Arabia.',
      en: 'Eman Ramadan Elsharkawy, et al. (2017). Comparative Study of Antioxidant and Anticancer Activity of Thuja orientalis Growing in Egypt and Saudi Arabia.',
    },
    {
      ar: 'Abdel-Raheim M. A. Donia, et al. (2017). UPLC-MS/MS method for Simultaneous quantification of glimepiride and metformin in human plasma.',
      en: 'Abdel-Raheim M. A. Donia, et al. (2017). UPLC-MS/MS method for Simultaneous quantification of glimepiride and metformin in human plasma.',
    },
    {
      ar: 'Asmaa Mahmoud Radwan, et al. (2018). Comparative studies on the effect of environmental pollution on secondary metabolite contents and genotoxicity of two plants in Asir area, Saudi Arabia.',
      en: 'Asmaa Mahmoud Radwan, et al. (2018). Comparative studies on the effect of environmental pollution on secondary metabolite contents and genotoxicity of two plants in Asir area, Saudi Arabia.',
    },
    {
      ar: 'Abdel-Raheim M.A. DONIA, et al. (2018). Chromatographic Stability Indicating Quantification of Ramipril in Bulk and Dosage Forms.',
      en: 'Abdel-Raheim M.A. DONIA, et al. (2018). Chromatographic Stability Indicating Quantification of Ramipril in Bulk and Dosage Forms.',
    },
    {
      ar: 'Fatma A. Ahmed, et al. (2022). Phytochemical Investigation, HPLC Analysis and Antimicrobial Activity of Some Plants from Chenopodiaceae Family.',
      en: 'Fatma A. Ahmed, et al. (2022). Phytochemical Investigation, HPLC Analysis and Antimicrobial Activity of Some Plants from Chenopodiaceae Family.',
    },
    {
      ar: 'Mohamed A. El-Sakhawy, et al. (2023). Oral candidiasis of tobacco smokers: A literature review.',
      en: 'Mohamed A. El-Sakhawy, et al. (2023). Oral candidiasis of tobacco smokers: A literature review.',
    },
    {
      ar: 'Asmaa M. Radwan, et al. (2023). Priming of Citrullus lanatus var. Colocynthoides seeds in seaweed extract improved seed germination, plant growth and performance under salinity conditions.',
      en: 'Asmaa M. Radwan, et al. (2023). Priming of Citrullus lanatus var. Colocynthoides seeds in seaweed extract improved seed germination, plant growth and performance under salinity conditions.',
    },
    {
      ar: 'Mohamed A. Balah, et al. (2024). Unveiling allelopathic dynamics and impacts of invasive Erigeron bonariensis and Bidens pilosa on plant communities and soil parameters.',
      en: 'Mohamed A. Balah, et al. (2024). Unveiling allelopathic dynamics and impacts of invasive Erigeron bonariensis and Bidens pilosa on plant communities and soil parameters.',
    },
    {
      ar: 'Rahmah Al-Qthanin, et al. (2024). Comprehensive Analysis and Implications of Veronica persica Germination and Growth Traits in their Invasion Ecology.',
      en: 'Rahmah Al-Qthanin, et al. (2024). Comprehensive Analysis and Implications of Veronica persica Germination and Growth Traits in their Invasion Ecology.',
    },
    {
      ar: 'Rahmah Al-Qthanin, et al. (2024). Potentials of invasive Bidens pilosa, Conyza bonariensis and Parthenium hysterophorus species based on germination patterns and growth traits.',
      en: 'Rahmah Al-Qthanin, et al. (2024). Potentials of invasive Bidens pilosa, Conyza bonariensis and Parthenium hysterophorus species based on germination patterns and growth traits.',
    },
    {
      ar: 'Rahmah Al-Qthanin, et al. (2024). Plant and soil characteristics affected by the allelopathic pathways of Avena fatua and Lolium temulentum weeds.',
      en: 'Rahmah Al-Qthanin, et al. (2024). Plant and soil characteristics affected by the allelopathic pathways of Avena fatua and Lolium temulentum weeds.',
    },
    {
      ar: 'Abeer Al-Andal, et al. (2025). A three-sided story: A biosystematic revision of genus Datura reveals novel tropane alkaloids for the first-time in certain species.',
      en: 'Abeer Al-Andal, et al. (2025). A three-sided story: A biosystematic revision of genus Datura reveals novel tropane alkaloids for the first-time in certain species.',
    },
    {
      ar: 'Abeer Al-Andal, et al. (2025). Allelopathic pathways and impacts of Chenopodium species via leachates, decaying residues, and essential oils.',
      en: 'Abeer Al-Andal, et al. (2025). Allelopathic pathways and impacts of Chenopodium species via leachates, decaying residues, and essential oils.',
    },
  ],
  otherScientificPubs: [
    {
      ar: 'اعداد برنامج فني الزراعة والبيئة وكتابة وحداته (وزارة التربية والتعليم الفني) -13/1/2021م',
      en: 'Preparation of the Agriculture and Environment Technician Program and writing its units (Ministry of Technical Education) - 1/13/2021',
    },
    {
      ar: 'Hand Book of basic chemical analysis, Desert Research Center- first edition, October 2019.',
      en: 'Hand Book of basic chemical analysis, Desert Research Center- first edition, October 2019.',
    },
  ],
  projectsAndPrograms: [
    {
      ar: 'Medicinal Plant Program, University of Massachusetts, Amherst, MA 01003 USA.',
      en: 'Medicinal Plant Program, University of Massachusetts, Amherst, MA 01003 USA.',
    },
    {
      ar: 'Development of Natural resources in North west coast of Egypt. Desert Research Center.',
      en: 'Development of Natural resources in North west coast of Egypt. Desert Research Center.',
    },
    {
      ar: 'Cytotoxic activity of Compounds isolated from Emex spinosa. Salman Bin Abdulaziz University, Al-Kharj, KSA.',
      en: 'Cytotoxic activity of Compounds isolated from Emex spinosa. Salman Bin Abdulaziz University, Al-Kharj, KSA.',
    },
    {
      ar: 'Effect of some Saudi medicinal plants on gastric ulcers. Salman Bin Abdulaziz University, Al-Kharj, KSA.',
      en: 'Effect of some Saudi medicinal plants on gastric ulcers. Salman Bin Abdulaziz University, Al-Kharj, KSA.',
    },
    {
      ar: 'Effect of Some Saudi Wild Plants on Male Fertility. Salman Bin Abdulaziz University, Al-Kharj, KSA.',
      en: 'Effect of Some Saudi Wild Plants on Male Fertility. Salman Bin Abdulaziz University, Al-Kharj, KSA.',
    },
    {
      ar: 'Quality control of some pharmaceutical and herbal products in Saudi Arabia (2016/03/6600) Prince Sattam bin Abdulaziz University.',
      en: 'Quality control of some pharmaceutical and herbal products in Saudi Arabia (2016/03/6600) Prince Sattam bin Abdulaziz University.',
    },
    {
      ar: 'Comparative study on the effect of environmental pollution on secondary metabolites and anatomical structure for some plants and soil heavy metal content in Asir area. Project Number 473 KKU.',
      en: 'Comparative study on the effect of environmental pollution on secondary metabolites and anatomical structure for some plants and soil heavy metal content in Asir area. Project Number 473 KKU.',
    },
    {
      ar: 'Development and Optimization of Halophyte-based Farming systems in salt-affected Mediterranean Soils .Acronym- HaloFarMs. 2019.',
      en: 'Development and Optimization of Halophyte-based Farming systems in salt-affected Mediterranean Soils .Acronym- HaloFarMs. 2019.',
    },
  ],
  conferencesAndWorkshops: [
    {
      ar: 'Effects of Nitrogen on the Yield and Quality of Selected Chinese Medicinal Plants of the Lamiaceae Family. 8th Annual Oxford International Conference on the Science of Botanicals, April 6–9, 2009, University of Mississippi, University, MS, USA.',
      en: 'Effects of Nitrogen on the Yield and Quality of Selected Chinese Medicinal Plants of the Lamiaceae Family. 8th Annual Oxford International Conference on the Science of Botanicals, April 6–9, 2009, University of Mississippi, University, MS, USA.',
    },
    {
      ar: 'Insecticidal Activity of Some Plant Extracts. 106th Annual International Conference of the American Society for Horticultural Science Millennium Hotel, St. Louis, Missouri. July 2009.',
      en: 'Insecticidal Activity of Some Plant Extracts. 106th Annual International Conference of the American Society for Horticultural Science Millennium Hotel, St. Louis, Missouri. July 2009.',
    },
  ],
};
