import { Researcher } from '../types';

export const hebaSayedIbrahim: Researcher = {
  name: {
    ar: 'هبة سيد ابراهيم سالم',
    en: 'Heba Sayed Ibrahim Salem',
  },
  title: {
    ar: 'باحث',
    en: 'Researcher',
  },
  contact: {
    emails: ['hebamicro2002@gmail.com'],
    phones: ['01000479071', '01221386246'],
    address: {
      ar: '',
      en: '',
    },
  },
  education: [
    {
      ar: 'دكتوراه فى العلوم/ قسم ميكروبيولوجى / كلية العلوم / جامعة عين شمس/2019. عنوان الرسالة : النشاط الضد فطرى لمستخلصات بعض النباتات الصحراوية ضد بعض العزلات الاكلينيكية و التوضيح الكيميائى للمركبات النشطة حيويا',
      en: 'PhD in Science, Microbiology Department, Faculty of Science, Ain Shams University, 2019. Thesis title: Antifungal activity of some desert plant extracts against some clinical isolates and chemical elucidation of bioactive compounds.',
    },
    {
      ar: 'دبلوم : تخصص الكيمياء الحيوية الآكلينيكية / كلية الطب البيطرى / جامعة بنها/ 2013',
      en: 'Diploma: Specialization in Clinical Biochemistry, Faculty of Veterinary Medicine, Benha University, 2013.',
    },
    {
      ar: 'ماجستير: ماجستير فى العلوم/ قسم ميكروبيولوجى / كلية العلوم / جامعة القاهره/2010. عنوان الرسالة :تقييم المواد الفعالة المعزولة من اوراق المانجو كمادة حافظة ضد الكائنات الدقيقة المصاحبة للمواد الغذائية',
      en: 'M.Sc. in Science, Microbiology Department, Faculty of Science, Cairo University, 2010. Thesis title: Evaluation of active substances isolated from mango leaves as a preservative against microorganisms associated with food.',
    },
    {
      ar: 'بكالوريوس : علوم قسم ميكروبيولوجى و كيمياء / كلية البنات/ جامعة عين شمس / 2002',
      en: 'B.Sc. in Science, Microbiology and Chemistry Department, Women’s College, Ain Shams University, 2002.',
    },
  ],
  careerProgression: [
    {
      ar: 'كيميائى تحاليل طبية',
      en: 'Medical analysis chemist',
    },
  ],
  publishedPapers: [
    {
      ar: 'فصل رقم 21 بعنوان "Forest fungi: Secondary metabolism, regulation, function and drug discovery" في كتاب "Forest Fungi /2025"',
      en: 'Chapter 21: "Forest fungi: Secondary metabolism, regulation, function and drug discovery" in book: Forest Fungi /2025',
    },
  ],
  scientificTheses: [],
};
