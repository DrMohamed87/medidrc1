import { Researcher } from '../types';

export const ramadanElshafay: Researcher = {
  name: {
    ar: 'رمضان مح الدين محمد اسماعيل الشافع',
    en: 'Ramadan Mohi El-Din Mohamed Ismail El-Shafay',
  },
  title: {
    ar: 'باحث بوحدة زراعة النباتات الطبية والعطرية',
    en: 'Researcher at the Unit of Cultivation of Medicinal and Aromatic Plants',
  },
  contact: {
    emails: ['ramadanelshafay68@gmail.com'],
    phones: ['0100422020'],
    address: {
      ar: 'وحدة زراعة النباتات الطبية والعطرية - قسم النباتات الطبية والعطرية - شعبة البيئة وزراعات المناطق الجافة - مركز بحوث الصحراء بالمطرية - القاهرة – مصر',
      en: 'Unit of Cultivation of Medicinal and Aromatic Plants - Department of Medicinal and Aromatic Plants - Division of Environment and Arid Lands Cultivation - Desert Research Center, Matareya - Cairo - Egypt',
    },
  },
  education: [
    {
      ar: 'دكتوراه العموم الزراعية - تخصص بساتين - زينة - كمية الزراعة - جامعة القاهرة. سنة 2005 م',
      en: 'PhD in Agricultural Science - Specialization in Horticulture - Ornamental - Faculty of Agriculture - Cairo University. 2005',
    },
    {
      ar: 'ماجستير العموم الزراعية - تخصص بساتين - زينة - كمية الزراعة - جامعة القاهرة. سنة 1997 م',
      en: 'M.Sc. in Agricultural Science - Specialization in Horticulture - Ornamental - Faculty of Agriculture - Cairo University. 1997',
    },
    {
      ar: 'بكالوريوس العموم الزراعية - تخصص بساتين - كمية الزراعة - جامعة القاهرة. سنة 1991م',
      en: 'B.Sc. in Agricultural Science - Specialization in Horticulture - Faculty of Agriculture - Cairo University. 1991',
    },
  ],
  careerProgression: [
    {
      ar: 'رئيس محطة بحوث سيوة من 2024 حتى الآن',
      en: 'Head of Siwa Research Station from 2024 to present',
    },
    {
      ar: 'باحث بوحدة زراعة النباتات الطبية والعطرية - قسم النباتات الطبية والعطرية - مركز بحوث الصحراء (2008-2025)',
      en: 'Researcher at the Unit of Cultivation of Medicinal and Aromatic Plants - Department of Medicinal and Aromatic Plants - Desert Research Center (2008-2025)',
    },
    {
      ar: 'اخصائ زراع بوحدة زراعة النباتات الطبية والعطرية - قسم النباتات الطبية والعطرية - مركز بحوث الصحراء (2005-2008)',
      en: 'Agricultural Specialist at the Unit of Cultivation of Medicinal and Aromatic Plants - Department of Medicinal and Aromatic Plants - Desert Research Center (2005-2008)',
    },
  ],
  publishedPapers: [
    {
      ar: 'Evaluation the impact of mulch technique and irrigation intervals on coriander Plant growth, productivity and volatile oil active components under southern valley (Toshka) conditions Horticulture Research Journal, 3(2), 2025, pp. 44-54.March 2025 ISSN 2974/4474',
      en: 'Evaluation the impact of mulch technique and irrigation intervals on coriander Plant growth, productivity and volatile oil active components under southern valley (Toshka) conditions Horticulture Research Journal, 3(2), 2025, pp. 44-54.March 2025 ISSN 2974/4474',
    },
    {
      ar: 'Effect of spraying with extracts of plants and amino acids on growth and productivity on Coriandrum sativum L. plants under Shalateen Conditions. Journal Archives, Vol. 21, Supplement 1, 2021, pp. 300-307. E-ISSN 2581-6063 (online). ISSN 0972-5210.',
      en: 'Effect of spraying with extracts of plants and amino acids on growth and productivity on Coriandrum sativum L. plants under Shalateen Conditions. Journal Archives, Vol. 21, Supplement 1, 2021, pp. 300-307. E-ISSN 2581-6063 (online). ISSN 0972-5210.',
    },
    {
      ar: 'Effect of organic fertilization and spraying aloe vera extract on the growth and productivity of Carum carvi L. under Shalateen conditions in Egypt. Journal of Plant Archives, Vol. 20, No. 2, 2020, pp. 4959-4971.',
      en: 'Effect of organic fertilization and spraying aloe vera extract on the growth and productivity of Carum carvi L. under Shalateen conditions in Egypt. Journal of Plant Archives, Vol. 20, No. 2, 2020, pp. 4959-4971.',
    },
    {
      ar: 'Integrated system for maximizing water unit productivity of Moringa Vegetative yield under Shalateen Conditions. Bioscience Research, 17(3), 2020, pp. 2298-2313.',
      en: 'Integrated system for maximizing water unit productivity of Moringa Vegetative yield under Shalateen Conditions. Bioscience Research, 17(3), 2020, pp. 2298-2313.',
    },
    {
      ar: 'Effect of location and environmental conditions on growth, yields, and chemical constituents of sweet basil (Ocimum basilicum L.). Journal of Agricultural Chemistry and Biotechnology, Mansoura University, Vol. 6(1), 2015, pp. 1–13.',
      en: 'Effect of location and environmental conditions on growth, yields, and chemical constituents of sweet basil (Ocimum basilicum L.). Journal of Agricultural Chemistry and Biotechnology, Mansoura University, Vol. 6(1), 2015, pp. 1–13.',
    },
    {
      ar: 'Evaluation the impact of salicylic acid on Origanum Syriacum L. Plant tolerance to saline water irrigation under North Sinai conditions. Horticulture Research Journal, 3 (2), 2025, pp. 55-62. March 2025, ISSN 2974/4474.',
      en: 'Evaluation the impact of salicylic acid on Origanum Syriacum L. Plant tolerance to saline water irrigation under North Sinai conditions. Horticulture Research Journal, 3 (2), 2025, pp. 55-62. March 2025, ISSN 2974/4474.',
    },
    {
      ar: 'Morphological and chemical characterizes responses of Moringa oleifera yield to localized irrigation systems, water restriction, and fertilizers. International Journal of Advanced Research, 9 (2), pp. 509-523. ISSN 2320-5407.',
      en: 'Morphological and chemical characterizes responses of Moringa oleifera yield to localized irrigation systems, water restriction, and fertilizers. International Journal of Advanced Research, 9 (2), pp. 509-523. ISSN 2320-5407.',
    },
    {
      ar: 'Effect of humic acid and acetyl salicylic acid on improving productivity of oregano (Origanum syriacum L.) plant Irrigated with saline water. Menoufia Journal of Plant Production, Vol. 4, October 2019, pp. 305–317.ISSN 2357- 0830',
      en: 'Effect of humic acid and acetyl salicylic acid on improving productivity of oregano (Origanum syriacum L.) plant Irrigated with saline water. Menoufia Journal of Plant Production, Vol. 4, October 2019, pp. 305–317.ISSN 2357- 0830',
    },
    {
      ar: 'Effect of saline water irrigation on growth and chemical composition of (Casuarina equisetifolia L.) seedlings. Egypt J. Hort. 26, No. 1, pp. 47-57 (1999).',
      en: 'Effect of saline water irrigation on growth and chemical composition of (Casuarina equisetifolia L.) seedlings. Egypt J. Hort. 26, No. 1, pp. 47-57 (1999).',
    },
    {
      ar: 'Effect of gamma rays on seeds germination and growth of some timber trees seedlings. Journal of Moshtohor, Annals of Agricultural Science, Moshtohor, (869–883), ISSN (Print): 1110-0419',
      en: 'Effect of gamma rays on seeds germination and growth of some timber trees seedlings. Journal of Moshtohor, Annals of Agricultural Science, Moshtohor, (869–883), ISSN (Print): 1110-0419',
    },
  ],
  scientificTheses: [],
  otherScientificPubs: [
    {
      ar: 'المشاركة ف إعداد كتاب عن النباتات الممحية بحلايب وشلاتين. ضمن ) مشروع تعظيم الاستفادة من النباتات الطبية البرية لتنمية المجتمعات السكانتية بمنطقة جنوب شرق مصر بالشلاتين .( الممول من اكاديمية البحث العمم – تنفيذ مركز بحوث الصحراء.( سنة 2016م',
      en: 'Participation in preparing a book on the plants of Halayeb and Shalateen. Within the project of maximizing the benefit of wild medicinal plants for the development of residential communities in the south-east of Egypt in Shalateen. (Funded by the Academy of Scientific Research - implemented by the Desert Research Center). 2016',
    },
    {
      ar: 'موسوعة "الاغذية الشعبية المصرية" تنفيذ المركز القوم لمبحوث وممول من اكاديمية البحث العمم . سنة 2020 م',
      en: 'Encyclopedia of "Egyptian Folk Foods" implemented by the National Research Center and funded by the Academy of Scientific Research. 2020',
    },
    {
      ar: 'اعداد التقارير الفنية والعممية لممحطات البحثية الت توليت ادارتها وكذلك التقارير العممية عن الظواهر النباتية والحقول الارشادية وفاعميات نتشاط المحطه البحثية وتقديمها بشكل دوري لادارة مركز بحوث الصحراء الذي يتول نتشرها ف مجمل انتجازات واعمال المركز. من 2008 حت 2025',
      en: 'Preparing technical and scientific reports for the research stations that I managed, as well as scientific reports on plant phenomena, demonstration fields, and the activities of the research station, and submitting them periodically to the management of the Desert Research Center, which publishes them in the summary of the center\'s achievements and work. From 2008 to 2025',
    },
    {
      ar: 'المشاركة ف اعداد ومراجعة العديد من النشرات العممية منها نتشرة تحت عنوان )المورينجا غذاء ودواء.( سنة 2015م',
      en: 'Participation in the preparation and review of many scientific bulletins, including a bulletin entitled (Moringa, food and medicine). 2015',
    },
  ],
  projectsAndPrograms: [
    {
      ar: 'منسق مقيم لمشروعات اكاديمية البحث العمم والتكنولوجيا بحلايب وشلاتين بالقرار رقم 407 لسنة .2014',
      en: 'Resident coordinator for the projects of the Academy of Scientific Research and Technology in Halayeb and Shalateen, by decree No. 407 of 2014.',
    },
    {
      ar: 'مشارك كباحث ف مشروع تعظيم الاستفادة من النباتات الطبية البرية لتنمية المجتمعات السكانتية بمنطقة جنوب شرق مصر بالشلاتين . )ممول من اكاديمية البحث العمم – تنفيذ مركز بحوث الصحراء.( سنة 2016/2015 م',
      en: 'Participant as a researcher in the project of maximizing the benefit of wild medicinal plants for the development of residential communities in the south-east of Egypt in Shalateen. (Funded by the Academy of Scientific Research - implemented by the Desert Research Center). 2015/2016',
    },
  ],
  conferencesAndWorkshops: [
    {
      ar: 'المؤتمر الدول الرابع لتحمية المياة. " Future of Water Desalination in .Egypt &the Middle East " - مستمع - 24-27 فبراير 2020',
      en: 'The 4th International Conference on Water Desalination. "Future of Water Desalination in Egypt & the Middle East" - Attendee - 24-27 February 2020',
    },
    {
      ar: 'ورشة عمل "Science Day" - مستمع - 2019/3/31',
      en: '"Science Day" Workshop - Attendee - 31/3/2019',
    },
    {
      ar: 'الممتق العمم الدول بدولة الصين )مكافحة التصحر بالدول العربية والصين.( - محاضر ومستمع - 2015/8/23 حت .2015/9/17',
      en: 'The International Scientific Forum in China (Combating Desertification in Arab Countries and China) - Speaker and Attendee - 23/8/2015 to 17/9/2015',
    },
  ],
  researchInterests: [
    {
      ar: 'إجراء البحوث والدراسات لمعرفة تأثير الإجهادات البيئية المختمفة وخاصة الصحراوية عمى نتمو وإنتتاجية النباتات الطبية والعطرية المختمفة.',
      en: 'Conducting research and studies to determine the effect of different environmental stresses, especially desert ones, on the growth and productivity of different medicinal and aromatic plants.',
    },
    {
      ar: 'توطين واستزراع الاصول النباتية البرية وخاصة النباتات الطبية والعطرية من وديان الصحراء إلى الحقول المزروعة.',
      en: 'Domestication and cultivation of wild plant genetic resources, especially medicinal and aromatic plants, from desert valleys to cultivated fields.',
    },
    {
      ar: 'زراعة وإنتتا النباتات الطبية والعطرية تحت مختمف الظروف المصرية.',
      en: 'Cultivation and production of medicinal and aromatic plants under various Egyptian conditions.',
    },
    {
      ar: 'تحسين وتقييم إنتتاجية بعض النباتات الطبية والعطرية غير التقميدية.',
      en: 'Improving and evaluating the productivity of some non-traditional medicinal and aromatic plants.',
    },
    {
      ar: 'الممارسات الزراعية الجيدة لزراعة النباتات الطبية والعطرية.',
      en: 'Good agricultural practices for the cultivation of medicinal and aromatic plants.',
    },
    {
      ar: 'تحسين جودة النباتات الطبية والعطرية ومكونتاتها الفعالة باستخدام المركبات الطبيعية والبعد عن أو تقميل استخدام الأسمدة الكيماوية.',
      en: 'Improving the quality of medicinal and aromatic plants and their active ingredients by using natural compounds and avoiding or reducing the use of chemical fertilizers.',
    },
  ],
};
