import React, { useState } from 'react';
import { useLanguage } from '../App';

type SubTab = 'history' | 'formerHeads' | 'achievements' | 'projects';

const SubTabButton: React.FC<{
  icon: string;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex-1 min-w-[150px] text-center px-4 py-3 font-semibold transition-all duration-300 border-b-4 focus:outline-none ${
      isActive
        ? 'border-[#2E7D32] text-[#2E7D32]'
        : 'border-transparent text-gray-500 hover:text-[#2E7D32] hover:bg-green-50'
    }`}
    role="tab"
    aria-selected={isActive}
  >
    <i className={`fas ${icon} me-2`}></i>
    {label}
  </button>
);

const AboutTheDepartment: React.FC = () => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);
    
    return (
    <div className="animate-fade-in space-y-6 text-gray-700 leading-relaxed">
        <p>
            {t(
                'أسس قسم النباتات الطبية والعطرية كجزء من شعبة البيئة وزراعات المناطق الجافة بمركز بحوث الصحراء، ليكون مركزاً متخصصاً في دراسة واستغلال الثروة النباتية الهائلة في البيئات الصحراوية المصرية. منذ نشأته، عمل القسم على تحقيق الريادة في مجال البحث العلمي التطبيقي، مع التركيز على النباتات التي تمتلك خصائص طبية وعطرية واعدة.',
                'The Department of Medicinal and Aromatic Plants was established as part of the Ecology and Dry Land Agriculture Division at the Desert Research Center, to be a specialized center for studying and utilizing the vast plant wealth in Egyptian desert environments. Since its inception, the department has worked to achieve leadership in the field of applied scientific research, focusing on plants with promising medicinal and aromatic properties.'
            )}
        </p>
        <p>
            {t(
                'يضم القسم ثلاث وحدات بحثية متكاملة هي: وحدة زراعة النباتات الطبية والعطرية، وحدة كيمياء النباتات، ووحدة المنتجات الطبيعية. تعمل هذه الوحدات بشكل متناغم لإجراء أبحاث شاملة تبدأ من استنباط أفضل الممارسات الزراعية لزراعة هذه النباتات في الظروف الصعبة، مروراً بالتحليل الكيميائي الدقيق للمكونات الفعالة، وانتهاءً بتطوير منتجات طبيعية مبتكرة ذات قيمة اقتصادية وصحية مضافة.',
                'The department includes three integrated research units: the Medicinal and Aromatic Plants Cultivation Unit, the Plant Chemistry Unit, and the Natural Products Unit. These units work harmoniously to conduct comprehensive research, starting from developing the best agricultural practices for cultivating these plants in harsh conditions, through the precise chemical analysis of active ingredients, and ending with the development of innovative natural products with added economic and health value.'
            )}
        </p>
        <p>
            {t(
                'يسعى القسم إلى أن يكون جسراً بين البحث العلمي والصناعة، من خلال نقل التكنولوجيا وتوفير حلول علمية تساهم في نمو قطاعات الأدوية، المكملات الغذائية، مستحضرات التجميل، والأغذية الوظيفية. كما يلتزم القسم ببناء القدرات وتدريب الكوادر الشابة، والمساهمة بفاعلية في تحقيق أهداف التنمية المستدامة ورؤية مصر 2030.',
                'The department strives to be a bridge between scientific research and industry by transferring technology and providing scientific solutions that contribute to the growth of the pharmaceutical, dietary supplement, cosmetic, and functional food sectors. The department is also committed to capacity building, training young cadres, and effectively contributing to achieving the Sustainable Development Goals and Egypt\'s Vision 2030.'
            )}
        </p>
    </div>
    );
};

const FormerHeads: React.FC = () => {
  const { lang } = useLanguage();
  const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);

  const heads = [
    { name: t('أ.د. محمد الشحات', 'Prof. Dr. Mohamed El-Shahat'), term: '1985 - 1992' },
    { name: t('أ.د. فاطمة عبد الباري', 'Prof. Dr. Fatima Abdel-Bari'), term: '1992 - 1999' },
    { name: t('أ.د. سعيد الأنصاري', 'Prof. Dr. Said Al-Ansari'), term: '1999 - 2005' },
    { name: t('أ.د. عادل القاضي', 'Prof. Dr. Adel El-Kady'), term: '2005 - 2011' },
    { name: t('أ.د. هدى بسيوني', 'Prof. Dr. Hoda Bassiouni'), term: '2011 - 2017' },
    { name: t('أ.د. أشرف خليل', 'Prof. Dr. Ashraf Khalil'), term: '2017 - 2022' },
    { name: t('أ.د. محمد أحمد عبد الوهاب', 'Prof. Dr. Mohamed Ahmed Abdel-Wahab'), term: '2022 - 2023' },
  ];
  
  return (
  <div className="animate-fade-in">
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {heads.map((head) => (
        <div key={head.name} className="bg-white p-5 rounded-lg shadow-sm border text-center transition-transform duration-300 hover:scale-105 hover:shadow-md">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-3">
                 <i className="fas fa-user-tie text-3xl text-gray-400"></i>
            </div>
            <h4 className="font-bold text-lg text-[#37474F]">{head.name}</h4>
            <p className="text-gray-500 text-sm">{head.term}</p>
        </div>
      ))}
    </div>
  </div>
  );
};

const AchievementCard: React.FC<{ icon: string; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex items-start space-x-4 rtl:space-x-reverse">
        <div className="flex-shrink-0 w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
            <i className={`fas ${icon} text-2xl text-[#2E7D32]`}></i>
        </div>
        <div>
            <h4 className="font-bold text-lg text-[#37474F]">{title}</h4>
            <p className="text-gray-600">{description}</p>
        </div>
    </div>
);

const DepartmentAchievements: React.FC = () => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);
    
    return (
    <div className="animate-fade-in grid grid-cols-1 md:grid-cols-2 gap-6">
        <AchievementCard 
            icon="fa-award" 
            title={t("براءات اختراع مسجلة", "Registered Patents")}
            description={t("تسجيل 5 براءات اختراع في مجال استخلاص المركبات الفعالة وتطبيقاتها.", "Registration of 5 patents in the field of active compound extraction and its applications.")}
        />
        <AchievementCard 
            icon="fa-medal" 
            title={t("جوائز علمية مرموقة", "Prestigious Scientific Awards")}
            description={t("حصول باحثي القسم على 3 جوائز وطنية تقديرًا لإسهاماتهم البحثية.", "The department's researchers have received 3 national awards in recognition of their research contributions.")}
        />
        <AchievementCard 
            icon="fa-globe-africa" 
            title={t("نشر دولي متميز", "Outstanding International Publications")}
            description={t("نشر أكثر من 150 بحثًا في مجلات علمية عالمية ذات معامل تأثير عالٍ.", "Publication of over 150 papers in international scientific journals with high impact factors.")}
        />
        <AchievementCard 
            icon="fa-handshake" 
            title={t("تعاون صناعي مثمر", "Fruitful Industrial Collaboration")}
            description={t("تطوير 4 منتجات طبيعية بالتعاون مع شركات الأدوية ومستحضرات التجميل.", "Development of 4 natural products in collaboration with pharmaceutical and cosmetic companies.")}
        />
    </div>
    );
};

const ProjectItem: React.FC<{ title: string; description: string; status: 'ongoing' | 'completed' }> = ({ title, description, status }) => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);

    return (
    <div className="border-b border-gray-200 py-4">
        <div className="flex justify-between items-center">
            <h4 className="font-bold text-lg text-[#37474F]">{title}</h4>
            <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                status === 'ongoing' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
            }`}>
                {status === 'ongoing' ? t('جاري', 'Ongoing') : t('مكتمل', 'Completed')}
            </span>
        </div>
        <p className="text-gray-600 mt-1">{description}</p>
    </div>
    );
};

const ResearchProjects: React.FC = () => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);

    return (
    <div className="animate-fade-in">
        <div className="mb-8">
            <h3 className="text-xl font-bold text-[#2E7D32] mb-4 pb-2 border-b-2 border-green-200">{t('مشاريع جارية', 'Ongoing Projects')}</h3>
            <div className="space-y-4">
                <ProjectItem 
                    title={t("تحسين إنتاجية نبات المورينجا تحت ظروف الإجهاد المائي", "Improving Moringa Plant Productivity under Water Stress Conditions")}
                    description={t("يهدف المشروع إلى تطوير معاملات زراعية مبتكرة لزيادة تحمل نبات المورينجا للجفاف مع الحفاظ على جودة مكوناته الغذائية.", "The project aims to develop innovative agricultural treatments to increase the drought tolerance of the Moringa plant while maintaining the quality of its nutritional components.")}
                    status="ongoing"
                />
                 <ProjectItem 
                    title={t("استكشاف النشاط المضاد للسرطان في نباتات صحراوية نادرة", "Exploring Anti-Cancer Activity in Rare Desert Plants")}
                    description={t("مشروع بحثي متقدم لفصل وتقييم المركبات الفعالة من نباتات واعدة ودراسة آليات عملها على الخلايا السرطانية.", "An advanced research project to isolate and evaluate active compounds from promising plants and study their mechanisms of action on cancer cells.")}
                    status="ongoing"
                />
            </div>
        </div>
        <div>
            <h3 className="text-xl font-bold text-[#2E7D32] mb-4 pb-2 border-b-2 border-green-200">{t('مشاريع مكتملة', 'Completed Projects')}</h3>
             <div className="space-y-4">
                <ProjectItem 
                    title={t("تطوير مبيد حيوي من الزيوت الطيارة لنبات الشيح", "Development of a Biopesticide from Wormwood Volatile Oils")}
                    description={t("تم بنجاح تطوير تركيبة فعالة وآمنة لمبيد حشري طبيعي يعتمد على زيت الشيح، وأثبت فاعليته ضد آفات المحاصيل الرئيسية.", "A safe and effective formulation for a natural insecticide based on wormwood oil was successfully developed, proving its effectiveness against major crop pests.")}
                    status="completed"
                />
                 <ProjectItem 
                    title={t("إنشاء قاعدة بيانات للنباتات الطبية في سيناء", "Establishment of a Database for Medicinal Plants in Sinai")}
                    description={t("تم إنجاز مسح شامل وتوثيق للنباتات الطبية في شبه جزيرة سيناء، مع تحليل بصمتها الكيميائية وتحديد استخداماتها التقليدية.", "A comprehensive survey and documentation of medicinal plants in the Sinai Peninsula were completed, including analysis of their chemical fingerprint and identification of their traditional uses.")}
                    status="completed"
                />
            </div>
        </div>
    </div>
    );
};


const AboutPage: React.FC = () => {
    const { lang } = useLanguage();
    const [activeSubTab, setActiveSubTab] = useState<SubTab>('history');
    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);

    const renderContent = () => {
        switch (activeSubTab) {
            case 'formerHeads': return <FormerHeads />;
            case 'achievements': return <DepartmentAchievements />;
            case 'projects': return <ResearchProjects />;
            case 'history': default: return <AboutTheDepartment />;
        }
    };
    
    return (
        <div className="animate-fade-in">
            <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-md p-6 md:p-8">
                <div className="mb-8 border-b border-gray-200">
                    <nav className="flex flex-wrap -mb-px" aria-label="Tabs">
                        <SubTabButton 
                            label={t("عن القسم", "About")} 
                            icon="fa-history" 
                            isActive={activeSubTab === 'history'} 
                            onClick={() => setActiveSubTab('history')} 
                        />
                        <SubTabButton 
                            label={t("رؤساء سابقون", "Former Heads")} 
                            icon="fa-users" 
                            isActive={activeSubTab === 'formerHeads'} 
                            onClick={() => setActiveSubTab('formerHeads')} 
                        />
                        <SubTabButton 
                            label={t("إنجازات القسم", "Achievements")}
                            icon="fa-trophy" 
                            isActive={activeSubTab === 'achievements'} 
                            onClick={() => setActiveSubTab('achievements')} 
                        />
                        <SubTabButton 
                            label={t("المشاريع البحثية", "Projects")} 
                            icon="fa-tasks" 
                            isActive={activeSubTab === 'projects'} 
                            onClick={() => setActiveSubTab('projects')} 
                        />
                    </nav>
                </div>
                
                <div className="mt-8 min-h-[300px]">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

export default AboutPage;