import React, { useState, useMemo } from 'react';
import { departmentData } from '../data/departmentData';
import ResearcherCard from '../components/ResearcherCard';
import { Researcher } from '../types';
import { useLanguage, Language, getFullNameWithTitle } from '../App';

interface ResearcherWithUnit extends Researcher {
    unitName: string;
    unitId: string;
}

const ResearchersPage: React.FC = () => {
    const { lang } = useLanguage();
    const [selectedUnitId, setSelectedUnitId] = useState<string>('all');
    const [selectedResearcher, setSelectedResearcher] = useState<ResearcherWithUnit | null>(null);

    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);

    const allResearchers: ResearcherWithUnit[] = useMemo(() =>
        departmentData.flatMap(unit =>
            unit.researchers.map(researcher => ({
                ...researcher,
                unitName: unit.name[lang],
                unitId: unit.id,
            }))
        ), [lang]);

    const researchersInSelectedUnit = useMemo(() => {
        if (selectedUnitId === 'all') {
            return allResearchers;
        }
        return allResearchers.filter(r => r.unitId === selectedUnitId);
    }, [selectedUnitId, allResearchers]);

    const handleUnitChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setSelectedUnitId(e.target.value);
    };

    const handleResearcherSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedFullName = e.target.value;
        if (!selectedFullName) return;

        const researcher = allResearchers.find(r => getFullNameWithTitle(r, lang) === selectedFullName);
        if (researcher) {
            setSelectedResearcher(researcher);
        }
    };

    const generateCvHtml = (researcher: ResearcherWithUnit, lang: Language, fullName: string): string => {
        const { title, contact, education, careerProgression, scientificTheses, publishedPapers, technicalBulletins, otherScientificPubs, projectsAndPrograms, conferencesAndWorkshops, unitName } = researcher;

        const createSection = (title: string, items?: { ar: string, en: string }[]): string => {
            if (!items || items.length === 0) return '';
            return `
                <div class="section">
                    <h2>${title}</h2>
                    <ul>
                        ${items.map(item => `<li>${item[lang]}</li>`).join('')}
                    </ul>
                </div>
            `;
        };

        const emailsHTML = contact.emails.length > 0 ? `<p class="contact-info">📧 ${contact.emails.join(' / ')}</p>` : '';
        const phonesHTML = contact.phones.length > 0 ? `<p class="contact-info">📞 ${contact.phones.join(' / ')}</p>` : '';

        return `
            <!DOCTYPE html>
            <html lang="${lang}" dir="${lang === 'ar' ? 'rtl' : 'ltr'}">
            <head>
                <meta charset="UTF-8">
                <title>${t('عرض السيرة الذاتية', 'CV View')} - ${fullName}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
                <style>
                    @page { size: A4; margin: 20mm 15mm; }
                    body { font-family: ${lang === 'ar' ? "'Cairo', sans-serif" : "'Roboto', sans-serif"}; font-size: 11pt; line-height: 1.6; color: #333; background-color: #f9f9f9; margin: 0; padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                    .page-container { max-width: 210mm; margin: 20px auto; padding: 20mm; background-color: white; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
                    .controls { position: fixed; top: 0; left: 0; right: 0; background: #2E7D32; padding: 10px 20px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.2); z-index: 1000; }
                    .controls button { background-color: white; color: #2E7D32; border: 2px solid #2E7D32; padding: 8px 16px; margin: 0 10px; border-radius: 5px; font-family: inherit; font-size: 14px; font-weight: bold; cursor: pointer; transition: all 0.3s ease; }
                    .cv-container { padding-top: 60px; }
                    .header { text-align: center; border-bottom: 2px solid #2E7D32; padding-bottom: 15px; margin-bottom: 25px; page-break-after: avoid; }
                    h1 { font-size: 28pt; font-weight: 700; color: #2E7D32; margin: 0 0 5px 0; }
                    .title-unit { font-size: 15pt; color: #555; margin: 0 0 10px 0; font-weight: 600; }
                    h2 { font-size: 16pt; font-weight: 700; color: #2E7D32; margin: 25px 0 10px 0; padding-bottom: 6px; border-bottom: 1.5px solid #AED581; page-break-after: avoid; }
                    ul { list-style-type: none; padding-inline-start: 5px; margin: 0; }
                    li { margin-bottom: 8px; padding-inline-start: 20px; position: relative; }
                    li::before { content: '▪'; position: absolute; ${lang === 'ar' ? 'right: 0;' : 'left: 0;'} top: 0px; color: #66BB6A; font-size: 14pt; }
                    @media print { .controls { display: none; } .page-container { box-shadow: none; margin:0; padding:0; } .cv-container { padding-top: 0; } }
                </style>
            </head>
            <body>
                 <div class="controls">
                    <button onclick="window.print()"><i class="fas fa-print"></i> ${t('طباعة / تحميل PDF', 'Print / Download PDF')}</button>
                    <button onclick="window.close()"><i class="fas fa-times"></i> ${t('إغلاق', 'Close')}</button>
                </div>
                <div class="page-container">
                    <div class="cv-container">
                        <header class="header">
                            <h1>${fullName}</h1>
                            <p class="title-unit">${title[lang]}${unitName ? ` - ${unitName}` : ''}</p>
                            ${emailsHTML} ${phonesHTML}
                        </header>
                        <main>
                            ${createSection(t('المؤهلات العلمية', 'Education'), education)}
                            ${createSection(t('التدرج الوظيفي', 'Career Progression'), careerProgression)}
                            ${createSection(t('الرسائل العلمية', 'Scientific Theses'), scientificTheses)}
                            ${createSection(t('الأبحاث المنشورة', 'Published Papers'), publishedPapers)}
                            ${createSection(t('النشرات الفنية', 'Technical Bulletins'), technicalBulletins)}
                            ${createSection(t('مقالات علمية أخرى', 'Other Scientific Publications'), otherScientificPubs)}
                            ${createSection(t('المشاريع والبرامج البحثية', 'Research Projects and Programs'), projectsAndPrograms)}
                            ${createSection(t('المؤتمرات وورش العمل', 'Conferences and Workshops'), conferencesAndWorkshops)}
                        </main>
                    </div>
                </div>
            </body>
            </html>
        `;
    };
    
    const handlePrint = (researcher: ResearcherWithUnit) => {
        const fullName = getFullNameWithTitle(researcher, lang);
        const content = generateCvHtml(researcher, lang, fullName);
        const printWindow = window.open('', '_blank');
        if (printWindow) {
            printWindow.document.open();
            printWindow.document.write(content);
            printWindow.document.close();
        }
    };

    if (selectedResearcher) {
        return (
            <div className="animate-fade-in max-w-4xl mx-auto">
                <button
                    onClick={() => setSelectedResearcher(null)}
                    className="mb-8 px-5 py-2 rounded-lg font-semibold transition-all duration-300 bg-white text-[#37474F] hover:bg-gray-100 border border-gray-300 flex items-center shadow-sm"
                >
                    <i className={`fas ${lang === 'ar' ? 'fa-arrow-right' : 'fa-arrow-left'} me-3`}></i>
                    {t('العودة إلى كل الباحثين', 'Back to All Researchers')}
                </button>
                <ResearcherCard researcher={selectedResearcher} unitName={selectedResearcher.unitName} />
            </div>
        );
    }

    return (
        <div className="animate-fade-in">
            <div className="text-center mb-12">
                <h2 className="text-4xl lg:text-5xl font-extrabold text-[#2E7D32]">
                    {t('فريق الباحثين', 'Our Researchers')}
                </h2>
                <p className="text-lg text-gray-600 mt-4">{t('تعرف على الخبراء والمتخصصين في قسمنا. استخدم الفلاتر أدناه للتصفح.', 'Meet the experts and specialists in our department. Use the filters below to browse.')}</p>
            </div>

            <div className="mb-12 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="unit-select" className="block text-sm font-medium text-gray-700 mb-2">
                        {t('فلترة حسب الوحدة:', 'Filter by Unit:')}
                    </label>
                    <select
                        id="unit-select"
                        value={selectedUnitId}
                        onChange={handleUnitChange}
                        className="w-full p-3 border border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-[#66BB6A] focus:border-transparent transition"
                    >
                        <option value="all">{t('كل الوحدات', 'All Units')}</option>
                        {departmentData.map(unit => (
                            <option key={unit.id} value={unit.id}>{unit.name[lang]}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label htmlFor="researcher-select" className="block text-sm font-medium text-gray-700 mb-2">
                        {t('اختيار باحث مباشر:', 'Direct Researcher Selection:')}
                    </label>
                    <select
                        id="researcher-select"
                        value=""
                        onChange={handleResearcherSelect}
                        className="w-full p-3 border border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-[#66BB6A] focus:border-transparent transition"
                        aria-label="Select a researcher to view details"
                    >
                        <option value="" disabled>{t('-- اختر باحثًا لعرض بياناته --', '-- Select a researcher to view details --')}</option>
                        {researchersInSelectedUnit.map(r => {
                            const fullName = getFullNameWithTitle(r, lang);
                            return <option key={r.name.en} value={fullName}>{fullName}</option>
                        })}
                    </select>
                </div>
            </div>

            {researchersInSelectedUnit.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {researchersInSelectedUnit.map((researcher) => {
                        const fullName = getFullNameWithTitle(researcher, lang);
                        return (
                        <div key={researcher.name.en} className="flex flex-col p-5 bg-white rounded-xl shadow-md border border-gray-200/80 transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
                            <div className="flex items-center space-x-4 rtl:space-x-reverse mb-4">
                                 <div className="flex-shrink-0 w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-4 border-white shadow-md">
                                    {researcher.imageUrl ? (
                                        <img src={researcher.imageUrl} alt={fullName} className="w-full h-full object-cover" />
                                    ) : (
                                        <i className="fas fa-user text-3xl text-gray-400"></i>
                                    )}
                                </div>
                                <div className="flex-1 min-w-0 text-start">
                                    <h3 className="text-lg font-bold text-[#2E7D32] truncate">{fullName}</h3>
                                    <p className="text-sm text-gray-500 truncate">{researcher.title[lang]}</p>
                                </div>
                            </div>

                            <div className="mt-auto pt-4 border-t border-gray-200 flex items-center justify-around gap-2">
                                <button
                                    onClick={() => setSelectedResearcher(researcher)}
                                    className="flex-1 flex items-center justify-center px-3 py-2 text-sm rounded-lg font-semibold transition-colors duration-300 bg-[#2E7D32] text-white hover:bg-[#1B5E20] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2E7D32]"
                                    aria-label={`${t('عرض بيانات', 'View details for')} ${fullName}`}
                                >
                                    <i className="fas fa-user-circle me-2"></i>
                                    {t('عرض البيانات', 'View Details')}
                                </button>
                                <button
                                    onClick={(e) => { e.stopPropagation(); handlePrint(researcher); }}
                                    className="flex-1 flex items-center justify-center px-3 py-2 text-sm rounded-lg font-semibold transition-colors duration-300 bg-white text-[#2E7D32] border border-[#2E7D32] hover:bg-green-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2E7D32]"
                                    aria-label={`${t('عرض/تحميل السيرة الذاتية لـ', 'View/Download CV for')} ${fullName}`}
                                >
                                    <i className="fas fa-file-pdf me-2"></i>
                                    {t('عرض/تحميل CV', 'View/Load CV')}
                                </button>
                            </div>
                        </div>
                    )})}
                </div>
            ) : (
                <div className="text-center py-12">
                    <i className="fas fa-box-open text-5xl text-gray-300 mb-4"></i>
                    <p className="text-gray-500 text-lg">{t('لا يوجد باحثون في هذه الوحدة.', 'No researchers in this unit.')}</p>
                </div>
            )}
        </div>
    );
};

export default ResearchersPage;