import React, { useState, useMemo } from 'react';
import { departmentData } from '../data/departmentData';
import { useLanguage, getFullNameWithTitle } from '../App';

const UnitsPage: React.FC = () => {
    const { lang } = useLanguage();
    const [selectedUnitId, setSelectedUnitId] = useState<string>(departmentData[0]?.id ?? '');
    const [expandedUnitId, setExpandedUnitId] = useState<string | null>(departmentData[0]?.id ?? null);

    const selectedUnit = useMemo(() => {
        return departmentData.find(unit => unit.id === selectedUnitId);
    }, [selectedUnitId]);

    const unitHead = useMemo(() => {
        // Find the researcher with the specific title indicating they are the head of the unit.
        // It's more robust to check for keywords in both languages.
        return selectedUnit?.researchers.find(r => 
            r.title.en.toLowerCase().includes('head of unit') || 
            r.title.ar.includes('رئيس الوحدة')
        );
    }, [selectedUnit]);

    const handleUnitClick = (unitId: string) => {
        setSelectedUnitId(unitId);
        setExpandedUnitId(prevId => (prevId === unitId ? null : unitId));
    };
    
    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;

    const DetailSection: React.FC<{ title: string; icon: string; children: React.ReactNode }> = ({ title, icon, children }) => (
        <div className="mb-8">
            <h4 className="text-xl font-bold text-[#37474F] mb-4 pb-3 border-b-2 border-green-200 flex items-center">
                <i className={`fas ${icon} me-3 text-[#2E7D32]`}></i>
                <span>{title}</span>
            </h4>
            <div className="text-gray-700 leading-relaxed space-y-3 prose max-w-none">
                {children}
            </div>
        </div>
    );

    return (
        <div className="animate-fade-in">
            <header className="text-center mb-12">
                <h2 className="text-4xl lg:text-5xl font-extrabold text-[#2E7D32]">
                    {t('وحدات القسم', 'Department Units')}
                </h2>
                <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                    {t('تعرف على الوحدات البحثية المتخصصة ومجالات عملها. اختر وحدة من القائمة لعرض تفاصيلها.', 'Learn about our specialized research units and their fields of work. Select a unit from the list to view its details.')}
                </p>
            </header>
            
            <div className="flex flex-col md:flex-row gap-8 lg:gap-12 max-w-7xl mx-auto">
                {/* Sidebar */}
                <aside className="md:w-1/3 lg:w-1/4 flex-shrink-0">
                    <div className="sticky top-24">
                         <h3 className="text-lg font-bold text-[#2E7D32] mb-3 px-2">{t('الوحدات البحثية', 'Research Units')}</h3>
                        <nav aria-label="Units Navigation">
                            <ul className="space-y-2">
                                {departmentData.map((unit) => {
                                    const isSelected = selectedUnitId === unit.id;
                                    const isExpanded = expandedUnitId === unit.id;
                                    const currentUnitHead = unit.researchers.find(r => 
                                        r.title.en.toLowerCase().includes('head of unit') || 
                                        r.title.ar.includes('رئيس الوحدة')
                                    );

                                    return (
                                        <li key={unit.id} className="bg-white rounded-lg shadow-sm border border-gray-200/80 overflow-hidden transition-shadow duration-300 hover:shadow-md">
                                            <button
                                                onClick={() => handleUnitClick(unit.id)}
                                                className={`w-full text-start flex items-center justify-between p-3 transition-all duration-200 text-base font-semibold ${
                                                    isSelected ? 'bg-[#2E7D32] text-white' : 'text-gray-700 hover:bg-green-50'
                                                }`}
                                                aria-current={isSelected ? 'page' : undefined}
                                                aria-expanded={isExpanded}
                                            >
                                                <div className="flex items-center">
                                                    <i className={`fas ${unit.icon} w-8 text-center text-xl me-3 ${isSelected ? 'text-white' : 'text-[#66BB6A]'}`}></i>
                                                    <span className="truncate">{unit.name[lang]}</span>
                                                </div>
                                                <i className={`fas fa-chevron-down transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''} ${isSelected ? 'text-white/70' : 'text-gray-500'}`}></i>
                                            </button>

                                            <div className={`grid transition-all duration-500 ease-in-out ${isExpanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                                                <div className="overflow-hidden">
                                                    {currentUnitHead ? (
                                                        <div className="p-3 bg-green-50 border-t border-green-200 flex items-center space-x-3 rtl:space-x-reverse">
                                                            <div className="w-12 h-12 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center overflow-hidden border-2 border-white shadow-sm">
                                                                {currentUnitHead.imageUrl ? (
                                                                    <img src={currentUnitHead.imageUrl} alt={currentUnitHead.name[lang]} className="w-full h-full object-cover" />
                                                                ) : (
                                                                    <i className="fas fa-user text-2xl text-gray-400"></i>
                                                                )}
                                                            </div>
                                                            <div>
                                                                <p className="font-bold text-sm text-gray-800">{getFullNameWithTitle(currentUnitHead, lang)}</p>
                                                                <p className="text-xs text-gray-500">{currentUnitHead.title[lang]}</p>
                                                            </div>
                                                        </div>
                                                    ) : (
                                                        <div className="p-3 text-center text-sm text-gray-500 bg-gray-50 border-t">
                                                            {t('لم يتم تحديد رئيس للوحدة.', 'Head of unit not specified.')}
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </li>
                                    );
                                })}
                            </ul>
                        </nav>
                    </div>
                </aside>

                {/* Content */}
                <main className="flex-1 min-w-0">
                    {selectedUnit ? (
                        <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8 border border-gray-200/80">
                             <h3 className="text-3xl font-extrabold text-[#2E7D32] mb-6 pb-4 border-b-2 border-green-200">
                                 {selectedUnit.name[lang]}
                             </h3>

                            {/* Unit Head */}
                            {unitHead && (
                                <div className="mb-8 bg-gradient-to-br from-green-50 to-white p-6 rounded-lg border border-green-200 shadow-sm">
                                    <h4 className="text-lg font-bold text-[#37474F] mb-4">
                                        <i className="fas fa-user-tie me-3 text-[#2E7D32]"></i>
                                        {t('رئيس الوحدة', 'Head of Unit')}
                                    </h4>
                                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                                        <div className="w-16 h-16 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center border-2 border-white shadow-sm overflow-hidden">
                                             {unitHead.imageUrl ? (
                                                <img src={unitHead.imageUrl} alt={unitHead.name[lang]} className="w-full h-full object-cover" />
                                                ) : (
                                                <i className="fas fa-user text-3xl text-gray-400"></i>
                                             )}
                                        </div>
                                        <div>
                                            <p className="text-xl font-bold text-gray-800">{getFullNameWithTitle(unitHead, lang)}</p>
                                            <p className="text-md text-gray-500">{unitHead.title[lang]}</p>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {selectedUnit.description && (
                                <DetailSection title={t("عن الوحدة", "About the Unit")} icon="fa-info-circle">
                                    <p>{selectedUnit.description[lang]}</p>
                                </DetailSection>
                            )}
                            
                             {selectedUnit.vision && (
                                <DetailSection title={t("الرؤية", "Vision")} icon="fa-eye">
                                    <p>{selectedUnit.vision[lang]}</p>
                                </DetailSection>
                            )}

                            {selectedUnit.goals && selectedUnit.goals.length > 0 && (
                                <DetailSection title={t("الأهداف الرئيسية", "Main Goals")} icon="fa-bullseye">
                                    <ul className="space-y-3">
                                        {selectedUnit.goals.map((goal, index) => (
                                            <li key={index} className="flex items-start">
                                                <i className="fas fa-check-circle text-[#66BB6A] me-3 mt-1.5 flex-shrink-0"></i>
                                                <span>{goal[lang]}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </DetailSection>
                            )}
                        </div>
                    ) : (
                         <div className="text-center py-12 bg-white rounded-xl shadow-lg">
                            <i className="fas fa-exclamation-triangle text-5xl text-gray-300 mb-4"></i>
                            <p className="text-gray-500 text-lg">{t('لم يتم العثور على بيانات الوحدة.', 'Unit data not found.')}</p>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default UnitsPage;