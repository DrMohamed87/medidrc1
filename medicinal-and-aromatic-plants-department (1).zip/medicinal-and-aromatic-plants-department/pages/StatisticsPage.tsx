import React, { useState, useMemo, FC, ReactNode, useRef } from 'react';
import { departmentData } from '../data/departmentData';
import { Researcher } from '../types';
import { useLanguage, Language } from '../App';

// --- TYPE DEFINITIONS ---
interface PublicationWithYear {
  type: 'paper' | 'bulletin' | 'other' | 'project' | 'conference' | 'thesis';
  text: string;
  year: number | null;
  researcherName: string;
}

interface ResearcherWithDetails extends Researcher {
  rank: string;
  unitName: string;
  totalPublications: number;
  totalProjects: number;
  totalConferences: number;
  totalOutputs: number;
  allOutputs: PublicationWithYear[];
}

type Tab = 'dashboard' | 'productivity' | 'researchers';
type SortKey = keyof ResearcherWithDetails | 'totalOutputs';

// --- HELPER FUNCTIONS ---
const getYearFromPublication = (pubString: string): number | null => {
  const match = pubString.match(/\b(199\d|20\d{2})\b/);
  return match ? parseInt(match[0], 10) : null;
};

// More specific rank mappings. Order matters: from most specific to least specific.
const rankMappings = [
    { keywords: ['أستاذ باحث مساعد', 'assistant research professor'], rank: { ar: 'أستاذ باحث مساعد', en: 'Assistant Research Professor' } },
    { keywords: ['أستاذ مساعد', 'assistant professor', 'associate professor'], rank: { ar: 'أستاذ مساعد', en: 'Assistant Professor' } },
    { keywords: ['أستاذ باحث', 'research professor'], rank: { ar: 'أستاذ باحث', en: 'Research Professor' } },
    { keywords: ['أستاذ', 'professor'], rank: { ar: 'أستاذ', en: 'Professor' } },
    { keywords: ['باحث مساعد', 'assistant researcher'], rank: { ar: 'باحث مساعد', en: 'Assistant Researcher' } },
    { keywords: ['باحث', 'researcher'], rank: { ar: 'باحث', en: 'Researcher' } },
    { keywords: ['باحثة دكتوراه', 'باحث دكتوراه', 'ph.d. candidate'], rank: { ar: 'باحث دكتوراه', en: 'Ph.D. Candidate' } },
    { keywords: ['اخصائي', 'specialist', 'engineer'], rank: { ar: 'اخصائي', en: 'Specialist' } }
];

// REVISED: getResearcherRank function for more accurate titles.
const getResearcherRank = (researcher: Researcher, lang: Language): string => {
    const title = researcher.title[lang].toLowerCase();
    
    for (const mapping of rankMappings) {
        for (const keyword of mapping.keywords) {
            if (title.includes(keyword)) {
                return mapping.rank[lang];
            }
        }
    }
    // Fallback to the original title if no standard rank is found.
    return researcher.title[lang];
};


// REVISED: Expanded rankOrder for logical sorting of the new specific ranks.
const rankOrder: { [key: string]: number } = {
  'Professor': 1, 'أستاذ': 1,
  'Research Professor': 2, 'أستاذ باحث': 2,
  'Assistant Professor': 3, 'أستاذ مساعد': 3,
  'Assistant Research Professor': 4, 'أستاذ باحث مساعد': 4,
  'Researcher': 5, 'باحث': 5,
  'Assistant Researcher': 6, 'باحث مساعد': 6,
  'Ph.D. Candidate': 7, 'باحث دكتوراه': 7,
  'Specialist': 8, 'اخصائي': 8,
};



const COLORS = ['#2E7D32', '#66BB6A', '#AED581', '#FFC107', '#3F51B5', '#03A9F4', '#FF5722', '#795548'];

// --- UI COMPONENTS ---
const TabsNav: FC<{ activeTab: Tab; setActiveTab: (tab: Tab) => void }> = ({ activeTab, setActiveTab }) => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;
    const tabs = [
            { id: 'dashboard', label: t('اللوحة الرئيسية', 'Dashboard'), icon: 'fa-tachometer-alt' },
            { id: 'productivity', label: t('الإنتاجية البحثية', 'Productivity'), icon: 'fa-chart-line' },
            { id: 'researchers', label: t('ملفات الباحثين', 'Researchers'), icon: 'fa-users' },
    ];
    return (
    <div className="flex justify-center bg-gray-100 p-2 rounded-xl shadow-inner mb-8">
        {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as Tab)}
                className={`flex-1 sm:flex-initial sm:px-6 py-3 text-sm sm:text-base font-bold rounded-lg transition-all duration-300 flex items-center justify-center gap-2 ${
                    activeTab === tab.id ? 'bg-[#2E7D32] text-white shadow-md' : 'bg-transparent text-gray-600 hover:bg-white/60'
                }`}
            >
                <i className={`fas ${tab.icon}`}></i>
                <span className="hidden sm:inline">{tab.label}</span>
            </button>
        ))}
    </div>
    );
};

const StatCard: FC<{ icon: string; value: string | number; label: string; }> = ({ icon, value, label }) => (
    <div className="bg-white rounded-xl shadow p-5 flex items-center gap-4 border-s-4 border-[#66BB6A]">
        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
            <i className={`fas ${icon} text-2xl text-[#2E7D32]`}></i>
        </div>
        <div>
            <p className="text-3xl font-extrabold text-[#37474F]">{value}</p>
            <h3 className="text-sm font-semibold text-gray-500">{label}</h3>
        </div>
    </div>
);

const ColumnChart: FC<{ data: { label: string; value: number }[]; title: string; }> = ({ data, title }) => {
    const [tooltip, setTooltip] = useState<{ x: number, y: number, label: string, value: number } | null>(null);
    const chartRef = useRef<HTMLDivElement>(null);
    const { lang } = useLanguage();

    const maxValue = Math.max(...data.map(d => d.value), 0);
    const yAxisTicks = 5;
    const yMax = maxValue > 0 ? Math.ceil(maxValue / yAxisTicks) * yAxisTicks : yAxisTicks;

    const handleMouseMove = (e: React.MouseEvent, item: { label: string, value: number }) => {
        if (!chartRef.current) return;
        const chartRect = chartRef.current.getBoundingClientRect();
        setTooltip({
            x: e.clientX - chartRect.left,
            y: e.clientY - chartRect.top,
            label: item.label,
            value: item.value
        });
    };

    const handleMouseLeave = () => setTooltip(null);
    
    return (
        <div className="bg-white p-6 rounded-xl shadow-lg border h-full flex flex-col" ref={chartRef} onMouseLeave={handleMouseLeave}>
            <h3 className="text-lg font-bold text-[#2E7D32] mb-4 text-center">{title}</h3>
            {data.length > 0 ? (
                <div className="flex-grow relative" style={{ minHeight: '200px' }}>
                    <svg width="100%" height="100%" className="overflow-visible">
                        <defs>
                            {COLORS.map((color, index) => (
                                <linearGradient key={index} id={`gradient-${index}`} x1="0" x2="0" y1="0" y2="1">
                                    <stop offset="0%" stopColor={color} stopOpacity="1" />
                                    <stop offset="100%" stopColor={color} stopOpacity="0.7" />
                                </linearGradient>
                            ))}
                        </defs>
                        <g className="y-axis text-xs text-gray-400">
                            {[...Array(yAxisTicks + 1)].map((_, i) => {
                                const y = 100 - (i / yAxisTicks) * 90;
                                const value = (i / yAxisTicks) * yMax;
                                return (
                                    <g key={i} transform="translate(0, -10)">
                                        <text x="25" y={`${y}%`} dy="-0.3em" textAnchor="end">{value}</text>
                                        <line x1="30" y1={`${y}%`} x2="100%" y2={`${y}%`} stroke="#E5E7EB" strokeWidth="1" strokeDasharray="2" />
                                    </g>
                                );
                            })}
                        </g>
                        <g className="bars" transform="translate(30, -10)">
                            {data.map((item, i) => {
                                const barHeight = yMax > 0 ? (item.value / yMax) * 90 : 0;
                                const totalBars = data.length;
                                const barWidth = Math.min(30, 80 / totalBars);
                                const gap = (100 - (totalBars * barWidth)) / (totalBars + 1);
                                const x = gap * (i + 1) + barWidth * i;
                                return (
                                    <g key={item.label}>
                                        <rect x={`${x}%`} y={`${100 - barHeight}%`} width={`${barWidth}%`} height={`${barHeight}%`} fill={`url(#gradient-${i % COLORS.length})`} className="transition-opacity duration-200 hover:opacity-80 cursor-pointer" rx="2" onMouseMove={(e) => handleMouseMove(e, item)}>
                                            <animate attributeName="height" from="0" to={`${barHeight}%`} dur="0.6s" fill="freeze" begin={`${i * 0.05}s`} calcMode="spline" keySplines="0.4 0 0.2 1" />
                                            <animate attributeName="y" from="100%" to={`${100 - barHeight}%`} dur="0.6s" fill="freeze" begin={`${i * 0.05}s`} calcMode="spline" keySplines="0.4 0 0.2 1" />
                                        </rect>
                                        <text x={`${x + barWidth / 2}%`} y="102%" textAnchor="middle" className="text-xs fill-current text-gray-500 truncate w-full">{item.label}</text>
                                    </g>
                                );
                            })}
                        </g>
                    </svg>
                    {tooltip && (
                        <div className="absolute p-2 text-xs bg-gray-800 text-white rounded-md shadow-lg pointer-events-none transition-transform duration-100" style={{ top: tooltip.y, left: tooltip.x, transform: 'translate(10px, -110%)' }}>
                            <div className="font-bold whitespace-nowrap">{tooltip.label}</div>
                            <div className="whitespace-nowrap">{lang === 'ar' ? 'القيمة' : 'Value'}: {tooltip.value}</div>
                        </div>
                    )}
                </div>
            ) : <div className="flex-grow flex items-center justify-center"><p className="text-gray-500 text-center py-4">{lang === 'ar' ? 'لا توجد بيانات لعرضها.' : 'No data to display.'}</p></div>}
        </div>
    );
};

const DonutChart: FC<{ data: { label: string; value: number }[]; title: string; }> = ({ data, title }) => {
    const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
    const { lang } = useLanguage();
    const total = data.reduce((sum, item) => sum + item.value, 0);
    if (total === 0) return <ColumnChart data={data} title={title} />; 
    let accumulated = 0;

    return (
        <div className="bg-white p-6 rounded-xl shadow-lg border h-full flex flex-col">
            <h3 className="text-lg font-bold text-[#2E7D32] mb-6 text-center">{title}</h3>
            <div className="flex-grow flex flex-col md:flex-row items-center justify-center gap-8">
                <div className="relative w-40 h-40">
                    <svg viewBox="0 0 36 36" className="w-full h-full block">
                        <circle cx="18" cy="18" r="15.915" fill="transparent" stroke="#E5E7EB" strokeWidth="3" />
                        {data.map((item, i) => {
                            const percentage = (item.value / total) * 100;
                            const strokeDasharray = `${percentage} ${100 - percentage}`;
                            const strokeDashoffset = -accumulated;
                            accumulated += percentage;
                            return (
                                <circle key={i} cx="18" cy="18" r="15.915" fill="transparent" stroke={COLORS[i % COLORS.length]} strokeWidth={hoveredIndex === i ? 4.5 : 3.5} strokeDasharray={strokeDasharray} strokeDashoffset={strokeDashoffset} transform="rotate(-90 18 18)" className="transition-all duration-300 cursor-pointer" onMouseEnter={() => setHoveredIndex(i)} onMouseLeave={() => setHoveredIndex(null)}>
                                    <title>{`${item.label}: ${item.value} (${((item.value/total)*100).toFixed(1)}%)`}</title>
                                </circle>
                            );
                        })}
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none text-center">
                        {hoveredIndex !== null ? (
                            <>
                                <span className="text-2xl font-bold" style={{color: COLORS[hoveredIndex % COLORS.length]}}>{data[hoveredIndex].value}</span>
                                <span className="text-xs text-gray-500 max-w-[100px] break-words">{data[hoveredIndex].label}</span>
                            </>
                        ) : (
                            <>
                                <span className="text-3xl font-bold text-gray-700">{total}</span>
                                <span className="text-sm text-gray-500">{lang === 'ar' ? 'الإجمالي' : 'Total'}</span>
                            </>
                        )}
                    </div>
                </div>
                <div className="w-full md:w-1/2">
                    {data.map((item, i) => (
                        <div key={i} className={`flex items-center justify-between py-1 text-sm rounded-md px-2 transition-all duration-200 ${hoveredIndex === i ? 'bg-gray-100' : ''}`} onMouseEnter={() => setHoveredIndex(i)} onMouseLeave={() => setHoveredIndex(null)}>
                            <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></span><span className="font-semibold text-gray-600">{item.label}</span></div>
                            <span className="font-bold text-gray-700">{item.value}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// --- TAB VIEW COMPONENTS ---
const DashboardView: FC<{ researchers: ResearcherWithDetails[] }> = ({ researchers }) => {
    const [unitFilter, setUnitFilter] = useState('all');
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;
    
    const stats = useMemo(() => {
        const filteredResearchers = unitFilter === 'all' ? researchers : researchers.filter(r => r.unitName === departmentData.find(u => u.id === unitFilter)?.name[lang]);
        const totalOutputs = filteredResearchers.reduce((sum, r) => sum + r.allOutputs.length, 0);
        const rankCounts = filteredResearchers.reduce((acc, r) => { acc[r.rank] = (acc[r.rank] || 0) + 1; return acc; }, {} as Record<string, number>);
        const outputTypeCounts = filteredResearchers.flatMap(r => r.allOutputs).reduce((acc, o) => { acc[o.type] = (acc[o.type] || 0) + 1; return acc; }, {} as Record<string, number>);
        const researchersByUnit = departmentData.map(unit => ({ label: unit.name[lang], value: unit.researchers.length }));

        return {
            cards: [
                { icon: 'fa-users', value: filteredResearchers.length, label: t('إجمالي الباحثين', 'Total Researchers') },
                { icon: 'fa-book-open', value: totalOutputs, label: t('إجمالي الإنتاج العلمي', 'Total Scientific Output') },
                { icon: 'fa-sitemap', value: departmentData.length, label: t('وحدة بحثية', 'Research Units') }
            ],
            rankData: Object.entries(rankCounts).sort(([a], [b]) => (rankOrder[a] || 99) - (rankOrder[b] || 99)).map(([label, value]) => ({ label, value })),
            outputTypeData: [
                { label: t('أبحاث منشورة', 'Papers'), value: outputTypeCounts['paper'] || 0 },
                { label: t('مشاريع وبرامج', 'Projects'), value: outputTypeCounts['project'] || 0 },
                { label: t('مؤتمرات وورش', 'Conferences'), value: outputTypeCounts['conference'] || 0 },
                { label: t('نشرات ومقالات', 'Other'), value: (outputTypeCounts['bulletin'] || 0) + (outputTypeCounts['other'] || 0) },
            ],
            researchersByUnit,
        };
    }, [unitFilter, researchers, lang]);

    return (
        <div className="space-y-8">
            <select onChange={e => setUnitFilter(e.target.value)} className="w-full max-w-sm p-3 border border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-[#66BB6A]">
                <option value="all">{t('القسم بالكامل', 'Entire Department')}</option>
                {departmentData.map(u => <option key={u.id} value={u.id}>{u.name[lang]}</option>)}
            </select>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {stats.cards.map(card => <StatCard key={card.label} {...card} />)}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <DonutChart title={t("توزيع الرتب العلمية", "Distribution of Academic Ranks")} data={stats.rankData} />
                <ColumnChart title={t("توزيع الإنتاج العلمي", "Distribution of Scientific Output")} data={stats.outputTypeData} />
            </div>
            {unitFilter === 'all' && <ColumnChart title={t("توزيع الباحثين على الوحدات", "Researcher Distribution by Unit")} data={stats.researchersByUnit} />}
        </div>
    );
};

const ProductivityView: FC<{ researchers: ResearcherWithDetails[] }> = ({ researchers }) => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;
    const [yearFrom, setYearFrom] = useState(1990);
    const [yearTo, setYearTo] = useState(new Date().getFullYear());
    const [typeFilter, setTypeFilter] = useState<string>('all');
    
    const allOutputs = useMemo(() => researchers.flatMap(r => r.allOutputs.map(o => ({...o, unit: r.unitName}))), [researchers]);
    const years = useMemo(() => Array.from(new Set(allOutputs.map(o => o.year).filter(Boolean) as number[])).sort((a,b)=>b-a), [allOutputs]);
    
    const filteredOutputs = useMemo(() => allOutputs.filter(o => o.year && o.year >= yearFrom && o.year <= yearTo && (typeFilter === 'all' || o.type === typeFilter)), [allOutputs, yearFrom, yearTo, typeFilter]);

    const timelineData = useMemo(() => {
        const counts = filteredOutputs.reduce((acc, o) => { acc[o.year!] = (acc[o.year!] || 0) + 1; return acc; }, {} as Record<number, number>);
        return Object.entries(counts).sort(([a], [b]) => +a - +b).map(([label, value]) => ({ label: String(label), value: +value }));
    }, [filteredOutputs]);

    return (
        <div className="space-y-8">
            <div className="bg-white p-4 rounded-xl shadow grid grid-cols-1 md:grid-cols-3 gap-4">
                <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} className="p-2 border rounded-lg bg-white">
                    <option value="all">{t('كل أنواع الإنتاج', 'All Output Types')}</option>
                    <option value="paper">{t('أبحاث منشورة', 'Published Papers')}</option>
                    <option value="project">{t('مشاريع وبرامج', 'Projects & Programs')}</option>
                    <option value="conference">{t('مؤتمرات وورش عمل', 'Conferences & Workshops')}</option>
                    <option value="thesis">{t('رسائل علمية', 'Theses')}</option>
                    <option value="other">{t('مقالات ونشرات', 'Articles & Bulletins')}</option>
                </select>
                <select value={yearFrom} onChange={e => setYearFrom(+e.target.value)} className="p-2 border rounded-lg bg-white">
                    <option disabled>{t('من عام', 'From Year')}</option>
                    {years.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
                <select value={yearTo} onChange={e => setYearTo(+e.target.value)} className="p-2 border rounded-lg bg-white">
                    <option disabled>{t('إلى عام', 'To Year')}</option>
                    {years.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
            </div>
            {timelineData.length > 0 ? <ColumnChart title={`${t('الإنتاجية العلمية من', 'Scientific Productivity from')} ${yearFrom} ${t('إلى', 'to')} ${yearTo}`} data={timelineData} /> : <div className="text-center p-8 bg-white rounded-xl shadow text-gray-500">{t('لا توجد بيانات كافية لعرض المخطط الزمني.', 'Not enough data to display timeline.')}</div> }
            <div className="bg-white p-6 rounded-xl shadow-lg border">
                <h3 className="text-lg font-bold text-[#2E7D32] mb-4">{t('قائمة الإنتاج العلمي', 'List of Scientific Output')} ({filteredOutputs.length})</h3>
                <div className="max-h-[500px] overflow-y-auto ps-2 space-y-4">
                    {filteredOutputs.length > 0 ? filteredOutputs.sort((a,b) => b.year! - a.year!).map((o, i) => (
                        <div key={i} className="border-b pb-2"><p className="text-gray-800">{o.text}</p><p className="text-sm text-gray-500 font-semibold">{o.researcherName} ({o.unit}) - {o.year}</p></div>
                    )) : <p className="text-gray-500 text-center py-4">{t('لا توجد نتائج تطابق معايير البحث.', 'No results match the search criteria.')}</p>}
                </div>
            </div>
        </div>
    );
};

const ResearcherInfographic: FC<{ researcher: ResearcherWithDetails; onBack: () => void }> = ({ researcher, onBack }) => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;

    const breakdownData = useMemo(() => [
        { label: t('أبحاث', 'Papers'), value: researcher.publishedPapers.length },
        { label: t('مشاريع', 'Projects'), value: researcher.totalProjects },
        { label: t('مؤتمرات', 'Conferences'), value: researcher.totalConferences },
        { label: t('إشراف علمي', 'Theses'), value: researcher.scientificTheses.length },
        { label: t('نشرات ومقالات', 'Other'), value: (researcher.technicalBulletins?.length || 0) + (researcher.otherScientificPubs?.length || 0) },
    ].filter(item => item.value > 0), [researcher, lang]);

    const productivityTimeline = useMemo(() => {
        const yearCounts: { [year: number]: number } = {};
        const currentYear = new Date().getFullYear();
        researcher.allOutputs.forEach(output => { if (output.year && output.year > currentYear - 10) { yearCounts[output.year] = (yearCounts[output.year] || 0) + 1; }});
        const timelineData = [];
        for (let year = currentYear - 9; year <= currentYear; year++) { timelineData.push({ label: year.toString(), value: yearCounts[year] || 0 }); }
        return timelineData;
    }, [researcher]);

    const recentActivities = useMemo(() => {
        const activityIcons: Record<PublicationWithYear['type'], string> = { paper: 'fa-newspaper', project: 'fa-tasks', conference: 'fa-calendar-check', thesis: 'fa-graduation-cap', bulletin: 'fa-file-alt', other: 'fa-feather-alt' };
        return researcher.allOutputs.filter(o => o.year).sort((a, b) => b.year! - a.year!).slice(0, 5).map(o => ({ ...o, icon: activityIcons[o.type] }));
    }, [researcher]);

    return (
        <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8 space-y-8 animate-fade-in">
            <button onClick={onBack} className="font-semibold text-[#2E7D32] hover:underline flex items-center gap-2">
                <i className={`fas ${lang === 'ar' ? 'fa-arrow-right' : 'fa-arrow-left'}`}></i> {t('العودة لقائمة الباحثين', 'Back to Researchers List')}
            </button>
            <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-start border-b pb-6">
                 <div className="w-28 h-28 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
                    {researcher.imageUrl ? (
                        <img src={researcher.imageUrl} alt={researcher.name[lang]} className="w-full h-full object-cover" />
                    ) : (
                        <i className="fas fa-user text-6xl text-gray-400"></i>
                    )}
                </div>
                <div>
                    <h3 className="text-3xl font-bold text-[#2E7D32]">{researcher.name[lang]}</h3>
                    <p className="text-xl text-gray-600">{researcher.rank} - {researcher.unitName}</p>
                </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard icon="fa-book-open" value={researcher.totalOutputs} label={t("إجمالي الإنتاج", "Total Outputs")} />
                <StatCard icon="fa-tasks" value={researcher.totalProjects} label={t("مشروع بحثي", "Projects")} />
                <StatCard icon="fa-chalkboard-teacher" value={researcher.totalConferences} label={t("مؤتمر وورشة عمل", "Conferences")} />
                <StatCard icon="fa-calendar-alt" value={`${(new Date().getFullYear()) - (getYearFromPublication(researcher.careerProgression[0]?.[lang] || '') || new Date().getFullYear())}+`} label={t("سنوات خبرة", "Years of Exp.")} />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <DonutChart title={t("توزيع الإنتاج العلمي", "Scientific Output Breakdown")} data={breakdownData} />
                <ColumnChart title={t("الإنتاجية في آخر 10 سنوات", "Productivity in Last 10 Years")} data={productivityTimeline} />
            </div>
            <div>
                <h3 className="text-lg font-bold text-[#2E7D32] mb-4">{t('أحدث 5 أنشطة', '5 Recent Activities')}</h3>
                <div className="space-y-4">
                    {recentActivities.map((activity, index) => (
                        <div key={index} className="flex items-start gap-4 p-3 bg-gray-50 rounded-lg">
                            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0"><i className={`fas ${activity.icon} text-[#2E7D32]`}></i></div>
                            <div><p className="text-gray-700 text-sm leading-relaxed">{activity.text}</p><p className="text-xs text-gray-500 font-semibold mt-1">{activity.year}</p></div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const ResearchersView: FC<{ researchers: ResearcherWithDetails[] }> = ({ researchers }) => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;
    const [selectedResearcher, setSelectedResearcher] = useState<ResearcherWithDetails | null>(null);
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'asc' | 'desc' }>({ key: 'totalOutputs', direction: 'desc' });

    const sortedResearchers = useMemo(() => {
        return [...researchers].sort((a, b) => {
            const key = sortConfig.key;
            let compare = 0;
    
            if (key === 'rank') {
                const rankA = rankOrder[a.rank] || 99;
                const rankB = rankOrder[b.rank] || 99;
                compare = rankA - rankB;
            } else if (key === 'name') {
                compare = a.name[lang].localeCompare(b.name[lang]);
            } else {
                const valA = a[key as keyof typeof a];
                const valB = b[key as keyof typeof b];
                if (typeof valA === 'number' && typeof valB === 'number') {
                    compare = valA - valB;
                }
            }
            
            if (compare === 0 && key !== 'name') {
                compare = a.name[lang].localeCompare(b.name[lang]);
            }
    
            return sortConfig.direction === 'asc' ? compare : -compare;
        });
    }, [researchers, sortConfig, lang]);

    const requestSort = (key: SortKey) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
        setSortConfig({ key, direction });
    };

    const SortableHeader: FC<{ sortKey: SortKey; children: ReactNode }> = ({ sortKey, children }) => (
        <th scope="col" className="p-3 cursor-pointer" onClick={() => requestSort(sortKey)}>
            <div className="flex items-center justify-start gap-1">
                {children}
                {sortConfig.key === sortKey && <i className={`fas fa-arrow-${sortConfig.direction === 'asc' ? 'up' : 'down'}`} />}
            </div>
        </th>
    );

    if (selectedResearcher) {
        return <ResearcherInfographic researcher={selectedResearcher} onBack={() => setSelectedResearcher(null)} />;
    }

    return (
        <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg border">
            <h3 className="text-xl font-bold text-[#2E7D32] mb-4">{t('قائمة الباحثين', 'List of Researchers')} ({researchers.length})</h3>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-start text-gray-700">
                    <thead className="text-xs text-gray-800 uppercase bg-gray-100">
                        <tr>
                            <SortableHeader sortKey="name">{t('الباحث', 'Researcher')}</SortableHeader>
                            <SortableHeader sortKey="rank">{t('الرتبة', 'Rank')}</SortableHeader>
                            <th scope="col" className="p-3 text-start">{t('الوحدة', 'Unit')}</th>
                            <SortableHeader sortKey="totalPublications">{t('أبحاث', 'Papers')}</SortableHeader>
                            <SortableHeader sortKey="totalProjects">{t('مشاريع', 'Projects')}</SortableHeader>
                            <SortableHeader sortKey="totalConferences">{t('مؤتمرات', 'Conf.')}</SortableHeader>
                            <SortableHeader sortKey="totalOutputs">{t('الإجمالي', 'Total')}</SortableHeader>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedResearchers.map(r => (
                            <tr key={r.name.en} onClick={() => setSelectedResearcher(r)} className="bg-white border-b hover:bg-green-50/50 cursor-pointer transition-colors duration-200">
                                <td className="p-3">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center overflow-hidden">
                                            {r.imageUrl ? (
                                                <img src={r.imageUrl} alt={r.name[lang]} className="w-full h-full object-cover" />
                                            ) : (
                                                <i className="fas fa-user text-xl text-gray-400"></i>
                                            )}
                                        </div>
                                        <span className="font-bold">{r.name[lang]}</span>
                                    </div>
                                </td>
                                <td className="p-3">{r.rank}</td>
                                <td className="p-3 text-gray-600">{r.unitName}</td>
                                <td className="p-3 text-center font-medium">{r.totalPublications}</td>
                                <td className="p-3 text-center font-medium">{r.totalProjects}</td>
                                <td className="p-3 text-center font-medium">{r.totalConferences}</td>
                                <td className="p-3 text-center font-bold text-lg text-[#2E7D32]">{r.totalOutputs}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};


// --- MAIN COMPONENT ---
const StatisticsPage: React.FC = () => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;
    const [activeTab, setActiveTab] = useState<Tab>('dashboard');

    const allResearchers = useMemo((): ResearcherWithDetails[] =>
        departmentData.flatMap(unit =>
            unit.researchers.map(r => {
                const papers = r.publishedPapers.map(p => ({ type: 'paper' as const, text: p[lang], year: getYearFromPublication(p[lang]), researcherName: r.name[lang] }));
                const bulletins = (r.technicalBulletins || []).map(p => ({ type: 'bulletin' as const, text: p[lang], year: getYearFromPublication(p[lang]), researcherName: r.name[lang] }));
                const others = (r.otherScientificPubs || []).map(p => ({ type: 'other' as const, text: p[lang], year: getYearFromPublication(p[lang]), researcherName: r.name[lang] }));
                const projects = (r.projectsAndPrograms || []).map(p => ({ type: 'project' as const, text: p[lang], year: getYearFromPublication(p[lang]), researcherName: r.name[lang] }));
                const conferences = (r.conferencesAndWorkshops || []).map(p => ({ type: 'conference' as const, text: p[lang], year: getYearFromPublication(p[lang]), researcherName: r.name[lang] }));
                const theses = r.scientificTheses.map(p => ({ type: 'thesis' as const, text: p[lang], year: getYearFromPublication(p[lang]), researcherName: r.name[lang] }));

                const allOutputs = [...papers, ...bulletins, ...others, ...projects, ...conferences, ...theses];
                return {
                    ...r,
                    unitName: unit.name[lang],
                    rank: getResearcherRank(r, lang),
                    totalPublications: papers.length + bulletins.length + others.length,
                    totalProjects: projects.length,
                    totalConferences: conferences.length,
                    totalOutputs: allOutputs.length,
                    allOutputs: allOutputs,
                };
            })
        ),
    [lang]);
    
    const renderContent = () => {
        switch (activeTab) {
            case 'productivity': return <ProductivityView researchers={allResearchers} />;
            case 'researchers': return <ResearchersView researchers={allResearchers} />;
            case 'dashboard':
            default: return <DashboardView researchers={allResearchers} />;
        }
    };
    
    return (
        <div className="animate-fade-in space-y-8">
            <header className="text-center">
                <h2 className="text-4xl lg:text-5xl font-extrabold text-[#2E7D32]">
                    {t('لوحة التحكم الإحصائية', 'Statistical Dashboard')}
                </h2>
                <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                   {t('استكشف بيانات وإنجازات القسم عبر أدوات تحليلية تفاعلية.', 'Explore the department\'s data and achievements through interactive analytical tools.')}
                </p>
            </header>
            <TabsNav activeTab={activeTab} setActiveTab={setActiveTab} />
            <main className="mt-8 bg-gray-50/50 p-2 sm:p-4 rounded-2xl border">
                {renderContent()}
            </main>
        </div>
    );
};

export default StatisticsPage;