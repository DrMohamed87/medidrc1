import React from 'react';
import HeadOfDepartment from '../components/HeadOfDepartment';
import { useLanguage } from '../App';

const HomePage: React.FC = () => {
  const { lang } = useLanguage();
  const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);

  return (
    <div className="space-y-10">
        <HeadOfDepartment />
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-md p-8 md:p-12 text-center animate-fade-in">
            <i className="fas fa-seedling text-6xl text-[#2E7D32] mb-6"></i>
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#2E7D32] mb-4">
                {t('أهلاً بكم في قسم النباتات الطبية والعطرية', 'Welcome to the Department of Medicinal & Aromatic Plants')}
            </h2>
            <p className="mt-4 text-lg text-gray-700 max-w-3xl mx-auto leading-relaxed">
                {t(
                    'نحن ملتزمون بالبحث العلمي المبتكر والتطوير المستدام في مجال النباتات الطبية والعطرية. يهدف قسمنا إلى استكشاف الإمكانيات الهائلة للثروة النباتية في البيئات الصحراوية، وتوظيفها لخدمة المجتمع وتحقيق التنمية.',
                    'We are committed to innovative scientific research and sustainable development in the field of medicinal and aromatic plants. Our department aims to explore the immense potential of plant wealth in desert environments and utilize it to serve the community and achieve development.'
                )}
            </p>
            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="p-6 border-s-4 border-[#66BB6A] text-start">
                    <h3 className="text-xl font-bold text-[#37474F] mb-2">{t('رؤيتنا', 'Our Vision')}</h3>
                    <p className="text-gray-700">{t('الريادة في بحوث النباتات الطبية والعطرية وتطبيقاتها على المستوى الإقليمي والعالمي.', 'Leadership in medicinal and aromatic plants research and its applications at the regional and global levels.')}</p>
                </div>
                <div className="p-6 border-s-4 border-[#66BB6A] text-start">
                    <h3 className="text-xl font-bold text-[#37474F] mb-2">{t('رسالتنا', 'Our Mission')}</h3>
                    <p className="text-gray-700">{t('إجراء بحوث علمية متقدمة، وتطوير منتجات طبيعية مبتكرة، وتقديم حلول مستدامة تساهم في الحفاظ على التنوع البيولوجي.', 'Conducting advanced scientific research, developing innovative natural products, and providing sustainable solutions that contribute to the conservation of biodiversity.')}</p>
                </div>
                <div className="p-6 border-s-4 border-[#66BB6A] text-start">
                    <h3 className="text-xl font-bold text-[#37474F] mb-2">{t('أهدافنا', 'Our Goals')}</h3>
                    <p className="text-gray-700">{t('تعزيز الزراعة المستدامة، استخلاص المركبات الفعالة، وتطوير منتجات ذات قيمة اقتصادية عالية.', 'Promoting sustainable agriculture, extracting active compounds, and developing products with high economic value.')}</p>
                </div>
            </div>
        </div>
    </div>
  );
};

export default HomePage;