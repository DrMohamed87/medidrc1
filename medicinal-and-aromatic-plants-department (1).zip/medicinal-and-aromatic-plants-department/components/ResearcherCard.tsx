import React, { useState, ReactNode } from 'react';
import { Researcher } from '../types';
import { useLanguage, Language, getFullNameWithTitle } from '../App';

const InfoItem: React.FC<{ icon: string; text: ReactNode }> = ({ icon, text }) => (
    <div className="flex items-start text-gray-700">
        <i className={`fas ${icon} w-6 text-center text-[#66BB6A] me-3 pt-1 text-base`}></i>
        <span className="flex-1 text-base">{text}</span>
    </div>
);

const AccordionSection: React.FC<{ title: string; icon: string; children: ReactNode; items?: any[] }> = ({ title, icon, children, items }) => {
    const [isOpen, setIsOpen] = useState(false);
    if (!items || items.length === 0) return null;

    return (
        <div className="border-b border-gray-200">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full text-start font-semibold text-[#37474F] p-4 hover:bg-gray-100 transition-colors duration-200 flex justify-between items-center"
                aria-expanded={isOpen}
            >
                <span className="flex items-center">
                    <i className={`fas ${icon} me-3 text-lg text-[#66BB6A] w-6 text-center`}></i>
                    {title}
                    <span className="bg-gray-200 text-gray-600 text-sm font-bold ms-2 px-2.5 py-0.5 rounded-full">{items.length}</span>
                </span>
                <i className={`fas fa-chevron-down transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}></i>
            </button>
            <div className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="overflow-hidden">
                     <div className="p-4 ps-8 bg-gray-50">
                        {children}
                    </div>
                </div>
            </div>
        </div>
    );
};


interface ResearcherCardProps {
    researcher: Researcher;
    unitName?: string;
}

const generateCvHtml = (researcher: Researcher, unitName: string | undefined, lang: Language, fullName: string): string => {
    const { title, contact, education, careerProgression, scientificTheses, publishedPapers, technicalBulletins, otherScientificPubs, projectsAndPrograms, conferencesAndWorkshops } = researcher;

    const t = (ar: string, en: string) => lang === 'ar' ? ar : en;

    const createSection = (title: string, items?: { ar: string, en: string }[]): string => {
        if (!items || items.length === 0) return '';
        return `
            <div class="section">
                <h2>${title}</h2>
                <ul>
                    ${items.map(item => `<li>${item[lang]}</li>`).join('')}
                </ul>
            </div>
        `;
    };

    const emailsHTML = contact.emails.length > 0 
        ? `<p class="contact-info">📧 ${contact.emails.join(' / ')}</p>` 
        : '';
    const phonesHTML = contact.phones.length > 0 
        ? `<p class="contact-info">📞 ${contact.phones.join(' / ')}</p>` 
        : '';

    return `
        <!DOCTYPE html>
        <html lang="${lang}" dir="${lang === 'ar' ? 'rtl' : 'ltr'}">
        <head>
            <meta charset="UTF-8">
            <title>${t('عرض السيرة الذاتية', 'CV View')} - ${fullName}</title>
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
            <style>
                @page { size: A4; margin: 20mm 15mm; }
                body {
                    font-family: ${lang === 'ar' ? "'Cairo', sans-serif" : "'Roboto', sans-serif"};
                    font-size: 11pt; line-height: 1.6; color: #333; background-color: #f9f9f9;
                    margin: 0; padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact;
                }
                .page-container { max-width: 210mm; margin: 20px auto; padding: 20mm; background-color: white; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
                .controls { position: fixed; top: 0; left: 0; right: 0; background: #2E7D32; padding: 10px 20px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.2); z-index: 1000; }
                .controls button { background-color: white; color: #2E7D32; border: 2px solid #2E7D32; padding: 8px 16px; margin: 0 10px; border-radius: 5px; font-family: inherit; font-size: 14px; font-weight: bold; cursor: pointer; transition: all 0.3s ease; }
                .controls button:hover { background-color: #f0fff0; }
                .cv-container { padding-top: 60px; }
                .header { text-align: center; border-bottom: 2px solid #2E7D32; padding-bottom: 15px; margin-bottom: 25px; page-break-after: avoid; }
                .header h1 { font-size: 28pt; font-weight: 700; color: #2E7D32; margin: 0 0 5px 0; }
                .header .title-unit { font-size: 15pt; color: #555; margin: 0 0 10px 0; font-weight: 600; }
                .contact-info { font-size: 12pt; color: #444; margin: 4px 0; }
                h2 { font-size: 16pt; font-weight: 700; color: #2E7D32; margin: 25px 0 10px 0; padding-bottom: 6px; border-bottom: 1.5px solid #AED581; page-break-after: avoid; }
                .section { margin-bottom: 15px; page-break-inside: avoid; }
                ul { list-style-type: none; padding-inline-start: 5px; margin: 0; }
                li { margin-bottom: 8px; padding-inline-start: 20px; position: relative; }
                li::before { content: '▪'; position: absolute; ${lang === 'ar' ? 'right: 0;' : 'left: 0;'} top: 0px; color: #66BB6A; font-size: 14pt; }
                @media print { body { background-color: white; } .controls { display: none; } .page-container { margin: 0; padding: 0; box-shadow: none; } .cv-container { padding-top: 0; } }
            </style>
        </head>
        <body>
            <div class="controls">
                <button onclick="window.print()"><i class="fas fa-print"></i> ${t('طباعة / تحميل PDF', 'Print / Download PDF')}</button>
                <button onclick="window.close()"><i class="fas fa-times"></i> ${t('إغلاق', 'Close')}</button>
            </div>
            <div class="page-container">
                <div class="cv-container">
                    <header class="header">
                        <h1>${fullName}</h1>
                        <p class="title-unit">${title[lang]}${unitName ? ` - ${unitName}` : ''}</p>
                        ${emailsHTML} ${phonesHTML}
                    </header>
                    <main>
                        ${createSection(t('المؤهلات العلمية', 'Education'), education)}
                        ${createSection(t('التدرج الوظيفي', 'Career Progression'), careerProgression)}
                        ${createSection(t('الرسائل العلمية', 'Scientific Theses'), scientificTheses)}
                        ${createSection(t('الأبحاث المنشورة', 'Published Papers'), publishedPapers)}
                        ${createSection(t('النشرات الفنية', 'Technical Bulletins'), technicalBulletins)}
                        ${createSection(t('مقالات علمية أخرى', 'Other Scientific Publications'), otherScientificPubs)}
                        ${createSection(t('المشاريع والبرامج البحثية', 'Research Projects and Programs'), projectsAndPrograms)}
                        ${createSection(t('المؤتمرات وورش العمل', 'Conferences and Workshops'), conferencesAndWorkshops)}
                    </main>
                </div>
            </div>
        </body>
        </html>
    `;
};


const ResearcherCard: React.FC<ResearcherCardProps> = ({ researcher, unitName }) => {
  const { lang } = useLanguage();
  
  const handlePrint = () => {
    const fullName = getFullNameWithTitle(researcher, lang);
    const content = generateCvHtml(researcher, unitName, lang, fullName);
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        printWindow.document.open();
        printWindow.document.write(content);
        printWindow.document.close();
    }
  };

  const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);
  const fullName = getFullNameWithTitle(researcher, lang);

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-200/80 overflow-hidden">
        <div className="p-6 bg-gradient-to-br from-green-50 to-white">
            <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-4 sm:space-y-0 sm:space-x-6 sm:rtl:space-x-reverse">
                <div className="flex-shrink-0">
                    <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
                        {researcher.imageUrl ? (
                            <img src={researcher.imageUrl} alt={fullName} className="w-full h-full object-cover" />
                        ) : (
                            <i className="fas fa-user text-6xl text-gray-400"></i>
                        )}
                    </div>
                </div>

                <div className="flex-1 text-center sm:text-start">
                    <h3 className="text-2xl md:text-3xl font-bold text-[#2E7D32]">{fullName}</h3>
                    <p className="text-lg text-gray-600">{researcher.title[lang]}</p>
                    {unitName && <p className="text-md text-gray-500 mt-1"><i className="fas fa-sitemap me-2 text-gray-400"></i>{unitName}</p>}
                </div>
            </div>
        </div>

        <div className="p-5 border-t border-b border-gray-200">
             <h4 className="font-bold text-lg mb-4 text-[#37474F]"><i className="fas fa-address-card me-2 text-[#66BB6A]"></i>{t('معلومات الاتصال', 'Contact Information')}</h4>
             <div className="space-y-3">
                {researcher.contact.emails.map(email => <InfoItem key={email} icon="fa-envelope" text={<a href={`mailto:${email}`} className="hover:underline text-blue-600">{email}</a>} />)}
                {researcher.contact.phones.map(phone => <InfoItem key={phone} icon="fa-phone" text={phone} />)}
                {researcher.office && <InfoItem icon="fa-map-marker-alt" text={researcher.office[lang]} />}
                <InfoItem icon="fa-location-arrow" text={researcher.contact.address[lang]} />
                {researcher.contact.links && researcher.contact.links.length > 0 && (
                     <InfoItem icon="fa-link" text={
                        <div className="flex flex-wrap gap-x-4 gap-y-2">
                            {researcher.contact.links.map(link => (
                                <a key={link.name} href={link.url} target="_blank" rel="noopener noreferrer" className="text-base font-semibold text-blue-600 hover:underline">
                                    {link.name}
                                </a>
                            ))}
                        </div>
                    } />
                )}
             </div>
        </div>

        <div className="p-5 bg-gray-50 border-b border-gray-200">
            <button
                onClick={handlePrint}
                className="w-full flex items-center justify-center px-4 py-3 rounded-lg font-semibold text-white bg-[#2E7D32] hover:bg-[#1B5E20] transition-colors duration-300 shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2E7D32]"
                aria-label={`${t('تحميل السيرة الذاتية لـ', 'Download CV for')} ${fullName}`}
            >
                <i className="fas fa-file-pdf me-3"></i>
                {t('عرض/تحميل السيرة الذاتية', 'View/Download CV')}
            </button>
        </div>
        
        <div className="bg-white">
            <AccordionSection title={t('المؤهلات العلمية', 'Education')} icon="fa-graduation-cap" items={researcher.education}>
                <div className="space-y-3">{researcher.education.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
            <AccordionSection title={t('التدرج الوظيفي', 'Career Progression')} icon="fa-briefcase" items={researcher.careerProgression}>
                 <div className="space-y-3">{researcher.careerProgression.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
            <AccordionSection title={t('الرسائل العلمية', 'Scientific Theses')} icon="fa-book-reader" items={researcher.scientificTheses}>
                <div className="space-y-3">{researcher.scientificTheses.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
            <AccordionSection title={t('الأبحاث المنشورة', 'Published Papers')} icon="fa-newspaper" items={researcher.publishedPapers}>
                <div className="space-y-3">{researcher.publishedPapers.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
            <AccordionSection title={t('النشرات الفنية', 'Technical Bulletins')} icon="fa-file-alt" items={researcher.technicalBulletins}>
                <div className="space-y-3">{researcher.technicalBulletins?.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
             <AccordionSection title={t('مقالات علمية أخرى', 'Other Scientific Publications')} icon="fa-feather-alt" items={researcher.otherScientificPubs}>
                 <div className="space-y-3">{researcher.otherScientificPubs?.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
            <AccordionSection title={t('المشاريع والبرامج البحثية', 'Projects & Programs')} icon="fa-tasks" items={researcher.projectsAndPrograms}>
                <div className="space-y-3">{researcher.projectsAndPrograms?.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
            <AccordionSection title={t('المؤتمرات وورش العمل', 'Conferences & Workshops')} icon="fa-calendar-check" items={researcher.conferencesAndWorkshops}>
                 <div className="space-y-3">{researcher.conferencesAndWorkshops?.map((item, index) => <InfoItem key={index} icon="fa-leaf" text={item[lang]} />)}</div>
            </AccordionSection>
        </div>
    </div>
  );
};

export default ResearcherCard;