
import React from 'react';

const icons = [
  { icon: 'fa-leaf', className: 'float-1' },
  { icon: 'fa-seedling', className: 'float-2' },
  { icon: 'fa-spa', className: 'float-3' },
  { icon: 'fa-leaf', className: 'float-4' },
  { icon: 'fa-seedling', className: 'float-5' },
  { icon: 'fa-spa', className: 'float-6' },
  { icon: 'fa-leaf', className: 'float-7' },
  { icon: 'fa-seedling', className: 'float-8' },
  { icon: 'fa-spa', className: 'float-9' },
  { icon: 'fa-leaf', className: 'float-10' },
];

const FloatingIcons: React.FC = () => {
  return (
    <div className="fixed top-0 left-0 w-full h-full pointer-events-none -z-10 overflow-hidden">
      {icons.map((item, index) => (
        <div key={index} className={`float-element ${item.className}`}>
          <i className={`fas ${item.icon}`}></i>
        </div>
      ))}
    </div>
  );
};

export default FloatingIcons;
