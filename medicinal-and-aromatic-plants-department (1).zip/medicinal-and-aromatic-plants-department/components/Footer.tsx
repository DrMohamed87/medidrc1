import React from 'react';
import { useLanguage } from '../App';

const socialLinks = [
    { icon: 'fab fa-facebook', href: '#' },
    { icon: 'fab fa-twitter', href: '#' },
    { icon: 'fab fa-instagram', href: '#' },
    { icon: 'fab fa-linkedin', href: '#' },
];

const Footer: React.FC = () => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);
    
    return (
        <footer className="bg-[#2E7D32] text-white/90 text-center py-10 mt-16">
            <div className="container mx-auto px-4">
                <div className="flex flex-col items-center">
                    <div className="text-5xl mb-4 text-[#AED581]">
                        <i className="fas fa-leaf"></i>
                    </div>
                    <p className="font-bold text-lg">
                        {t('© 2024 قسم النباتات الطبية والعطرية - مركز بحوث الصحراء', '© 2024 Dept. of Medicinal & Aromatic Plants - Desert Research Center')}
                    </p>
                    <p className="text-sm opacity-80">
                        {t('جميع الحقوق محفوظة', 'All rights reserved')}
                    </p>
                    <div className="flex justify-center my-6 space-x-4">
                        {socialLinks.map((link, index) => (
                            <a 
                                key={index} 
                                href={link.href}
                                className="text-2xl text-white/70 hover:text-white hover:scale-110 transition-transform duration-300"
                                aria-label={`Follow us on ${link.icon.split('-')[1]}`}
                            >
                                <i className={link.icon}></i>
                            </a>
                        ))}
                    </div>
                    <p className="text-xs opacity-60">
                        {t('تصميم وتطوير: إدارة تكنولوجيا المعلومات بالمركز', 'Design and Development: DRC IT Department')}
                    </p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;