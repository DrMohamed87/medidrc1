import React from 'react';
import { useLanguage } from '../App';

const LanguageSwitcher: React.FC = () => {
  const { lang, setLang } = useLanguage();

  const toggleLanguage = () => {
    const newLang = lang === 'ar' ? 'en' : 'ar';
    setLang(newLang);
  };

  return (
    <button
      onClick={toggleLanguage}
      className="absolute top-4 start-4 sm:start-6 lg:start-8 bg-white/50 px-3 py-2 rounded-md text-sm font-semibold text-[#2E7D32] border border-green-200 shadow-sm hover:bg-white transition-all duration-300 flex items-center gap-2"
      aria-label="Toggle Language"
    >
      <i className="fas fa-globe"></i>
      {lang === 'ar' ? <>&nbsp;English&nbsp;🇺🇸</> : <>&nbsp;العربية&nbsp;🇪🇬</>}
    </button>
  );
};


const Header: React.FC = () => {
  const { t } = useLanguage();
  return (
    <header 
      className="bg-gradient-to-br from-emerald-50 via-green-50 to-white py-12 text-center border-b-2 border-green-100 relative"
      aria-labelledby="site-title"
    >
        <div className="container mx-auto px-4">
             <LanguageSwitcher />
            <a href="https://drc.gov.eg/" target="_blank" rel="noopener noreferrer" aria-label="الموقع الرسمي لمركز بحوث الصحراء" className="absolute top-4 end-4 sm:end-6 lg:end-8">
                <img 
                    src="https://c.top4top.io/p_3535fba5o1.png" 
                    alt="لوجو مركز بحوث الصحراء"
                    className="w-24 h-auto transition-transform duration-300 hover:scale-105"
                />
            </a>
            <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
                <div className="w-32 h-32 bg-white rounded-full flex justify-center items-center shadow-2xl transition-all duration-300 hover:scale-110 hover:shadow-green-200/50 hover:-rotate-6 ring-4 ring-green-100">
                    <i className="fas fa-leaf text-7xl text-[#2E7D32] transition-transform duration-300 group-hover:scale-110" aria-hidden="true"></i>
                </div>
                <div className="md:ms-6">
                    <h1 
                      id="site-title"
                      className="text-4xl md:text-5xl font-extrabold text-[#2E7D32] tracking-tight"
                      style={{ textShadow: '1px 2px 3px rgba(46, 125, 50, 0.2)' }}
                    >
                      {t('departmentName')}
                    </h1>
                    <p className="text-lg text-green-800/90 mt-2 font-medium">
                      {t('researchCenter')}
                    </p>
                </div>
            </div>
        </div>
    </header>
  );
};

export default Header;