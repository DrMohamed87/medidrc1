import React from 'react';
import { useLanguage } from '../App';

const HeadOfDepartment: React.FC = () => {
    const { lang } = useLanguage();
    const t = (ar: string, en: string) => (lang === 'ar' ? ar : en);

    return (
        <section className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-6 md:p-10 border-t-8 border-green-600 animate-fade-in">
            <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-shrink-0">
                    <div className="w-40 h-40 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-4 border-white shadow-lg transform hover:scale-105 transition-transform duration-300">
                        <img src="https://k.top4top.io/p_3535c4kqf1.png" alt={t('أ.د. وليد محمد عبد العظيم', 'Prof. Dr. Waleed Mohamed Abd Elazeem')} className="w-full h-full object-cover" />
                    </div>
                </div>
                <div className="text-center md:text-start flex-1">
                    <h3 className="text-3xl font-bold text-[#2E7D32]">{t('أ.د. وليد محمد عبد العظيم', 'Prof. Dr. Waleed Mohamed Abd Elazeem')}</h3>
                    <p className="text-lg text-gray-600 font-semibold mb-4">{t('رئيس قسم النباتات الطبية والعطرية', 'Head of the Dept. of Medicinal & Aromatic Plants')}</p>
                    <blockquote className="text-gray-700 italic border-s-4 border-green-300 ps-4 py-2 bg-green-50/50 rounded-s-md">
                        {t(
                            '"باسم جميع أعضاء قسم النباتات الطبية والعطرية، أرحب بكم في بوابتنا الرقمية. نحن نفخر بتاريخنا العريق في البحث العلمي ونسعى دائمًا لتوظيف ثروات صحارينا الطبيعية لخدمة مجتمعنا ووطننا. نلتزم بالتميز والابتكار، وندعوكم لاستكشاف إنجازاتنا والمشاركة في رحلتنا نحو مستقبل أكثر استدامة وازدهارًا."',
                            '"On behalf of all members of the Department of Medicinal and Aromatic Plants, I welcome you to our digital portal. We are proud of our rich history in scientific research and always strive to utilize the natural wealth of our deserts to serve our community and nation. We are committed to excellence and innovation, and we invite you to explore our achievements and join us on our journey towards a more sustainable and prosperous future."'
                        )}
                    </blockquote>
                </div>
            </div>
        </section>
    );
};

export default HeadOfDepartment;