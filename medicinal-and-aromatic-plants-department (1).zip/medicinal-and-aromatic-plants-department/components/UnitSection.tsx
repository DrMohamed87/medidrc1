import React from 'react';
import { Unit } from '../types';
import ResearcherCard from './ResearcherCard';
import { useLanguage } from '../App';

interface UnitSectionProps {
  unit: Unit;
  isOpen: boolean;
  onToggle: () => void;
}

const DetailSection: React.FC<{ title: string; icon: string; children: React.ReactNode }> = ({ title, icon, children }) => (
    <div className="mb-6">
        <h4 className="text-xl font-bold text-[#37474F] mb-3 pb-2 border-b-2 border-green-200">
            <i className={`fas ${icon} me-3 text-[#2E7D32]`}></i>
            {title}
        </h4>
        <div className="text-gray-700 leading-relaxed space-y-2">
            {children}
        </div>
    </div>
);


const UnitSection: React.FC<UnitSectionProps> = ({ unit, isOpen, onToggle }) => {
  const { lang } = useLanguage();
  return (
    <section id={unit.id} className="transition-all duration-300">
        <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-xl">
            <header
              className="p-6 cursor-pointer border-s-8 border-[#2E7D32] flex justify-between items-center"
              onClick={onToggle}
              aria-expanded={isOpen}
              aria-controls={`unit-content-${unit.id}`}
            >
              <div className="flex items-center space-x-4">
                <i className={`${unit.icon} text-4xl text-[#2E7D32]`}></i>
                <h3 className="text-2xl font-bold text-[#2C3E50]">{unit.name[lang]}</h3>
              </div>
              <i className={`fas fa-chevron-down text-2xl text-gray-500 transition-transform duration-500 ${isOpen ? 'rotate-180' : ''}`}></i>
            </header>
            <div id={`unit-content-${unit.id}`} className={`grid transition-all duration-700 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="overflow-hidden">
                    <div className="p-6 md:p-8 bg-gray-50/50">
                        {/* Unit Details */}
                        <div className="mb-8 border-b border-gray-200 pb-8">
                            {unit.description && (
                                <DetailSection title={lang === 'ar' ? "عن الوحدة" : "About the Unit"} icon="fa-info-circle">
                                    <p>{unit.description[lang]}</p>
                                </DetailSection>
                            )}
                            <div className="grid md:grid-cols-2 gap-8">
                                {unit.vision && (
                                    <DetailSection title={lang === 'ar' ? "الرؤية" : "Vision"} icon="fa-eye">
                                        <p>{unit.vision[lang]}</p>
                                    </DetailSection>
                                )}
                                {unit.goals && unit.goals.length > 0 && (
                                    <DetailSection title={lang === 'ar' ? "الأهداف الرئيسية" : "Main Goals"} icon="fa-bullseye">
                                        <ul className="space-y-2">
                                            {unit.goals.map((goal, index) => (
                                                <li key={index} className="flex items-start">
                                                    <i className="fas fa-check-circle text-[#66BB6A] me-3 mt-1"></i>
                                                    <span>{goal[lang]}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </DetailSection>
                                )}
                            </div>
                        </div>

                        {/* Researchers */}
                        <div>
                            <h4 className="text-2xl font-bold text-[#37474F] mb-6">
                                <i className="fas fa-users me-3 text-[#2E7D32]"></i>
                                {lang === 'ar' ? 'الباحثون في الوحدة' : 'Researchers in the Unit'}
                            </h4>
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                {unit.researchers.map((researcher, index) => (
                                    <ResearcherCard key={index} researcher={researcher} unitName={unit.name[lang]} />
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default UnitSection;