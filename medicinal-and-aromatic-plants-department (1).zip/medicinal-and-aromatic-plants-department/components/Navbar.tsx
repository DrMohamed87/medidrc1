
import React, { useState } from 'react';

const navItems = [
    { href: '#unit1', text: 'زراعة النباتات', icon: 'fa-seedling' },
    { href: '#unit2', text: 'كيمياء النبات', icon: 'fa-flask' },
    { href: '#unit3', text: 'المنتجات الطبيعية', icon: 'fa-pills' },
];

const Navbar: React.FC = () => {
    const [activeLink, setActiveLink] = useState('#unit1');

    const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
        // We use native smooth scrolling via CSS, but we still update state for active class.
        setActiveLink(href);
    };

    return (
        <nav className="bg-[#FBF9F1]/80 backdrop-blur-sm sticky top-0 z-40 shadow-sm">
            <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex-shrink-0 text-[#004d40] text-xl font-bold">
                        <i className="fas fa-leaf ml-2"></i>
                        <span>الأقسام</span>
                    </div>
                    <div className="hidden md:block">
                        <ul className="flex items-baseline space-x-4 space-x-reverse">
                            {navItems.map((item) => (
                                <li key={item.href}>
                                    <a
                                        href={item.href}
                                        onClick={(e) => handleNavClick(e, item.href)}
                                        className={`relative flex items-center text-[#2C3E50] px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300 hover:text-[#004d40] group`}
                                    >
                                        <i className={`fas ${item.icon} ml-2 text-gray-400 group-hover:text-[#8FBC8F] transition-colors duration-300`}></i>
                                        {item.text}
                                        <span className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#004d40] transition-transform duration-300 scale-x-0 group-hover:scale-x-100 ${
                                            activeLink === item.href ? 'scale-x-100' : ''
                                        }`}></span>
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
