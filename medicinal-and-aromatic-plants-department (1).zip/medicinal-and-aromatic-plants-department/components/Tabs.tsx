import React from 'react';
import { Tab, useLanguage } from '../App';

interface TabsProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const tabItems: { id: Tab, icon: string }[] = [
    { id: 'home', icon: 'fa-home' },
    { id: 'about', icon: 'fa-info-circle' },
    { id: 'units', icon: 'fa-sitemap' },
    { id: 'researchers', icon: 'fa-users' },
    { id: 'statistics', icon: 'fa-chart-pie' },
];

const Tabs: React.FC<TabsProps> = ({ activeTab, onTabChange }) => {
    const { t } = useLanguage();

    return (
        <div className="bg-[#F8FBF6]/80 backdrop-blur-sm sticky top-0 z-40 shadow-sm border-b border-gray-200">
            <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-center h-16">
                    <ul className="flex items-baseline space-x-2 sm:space-x-4">
                        {tabItems.map((item) => (
                            <li key={item.id}>
                                <button
                                    onClick={() => onTabChange(item.id)}
                                    className={`flex items-center px-3 sm:px-4 py-2 rounded-lg text-sm sm:text-base font-medium transition-all duration-300 group focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2E7D32] ${
                                        activeTab === item.id 
                                        ? 'bg-[#2E7D32] text-white shadow-lg' 
                                        : 'text-[#37474F] hover:bg-green-100 hover:text-[#2E7D32]'
                                    }`}
                                    aria-current={activeTab === item.id ? 'page' : undefined}
                                >
                                    <i className={`fas ${item.icon} me-2 transition-colors duration-300 ${
                                        activeTab === item.id 
                                        ? 'text-white' 
                                        : 'text-gray-400 group-hover:text-[#2E7D32]'
                                    }`}></i>
                                    {t(item.id)}
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Tabs;