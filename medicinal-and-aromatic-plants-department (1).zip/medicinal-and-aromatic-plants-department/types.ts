export type LocalizedString = {
  ar: string;
  en: string;
};

export interface LocalizedLink {
  name: LocalizedString;
  url: string;
}

export interface Link {
  name: string;
  url: string;
}

export interface Researcher {
  name: LocalizedString;
  title: LocalizedString;
  imageUrl?: string;
  contact: {
    emails: string[];
    phones: string[];
    address: LocalizedString;
    links?: Link[];
  };
  education: LocalizedString[];
  careerProgression: LocalizedString[];
  scientificTheses: LocalizedString[];
  publishedPapers: LocalizedString[];
  technicalBulletins?: LocalizedString[];
  otherScientificPubs?: LocalizedString[];
  projectsAndPrograms?: LocalizedString[];
  conferencesAndWorkshops?: LocalizedString[];
  researchInterests?: LocalizedString[];
  office?: LocalizedString;
}


export interface Unit {
  id: string;
  name: LocalizedString;
  icon: string;
  description?: LocalizedString;
  vision?: LocalizedString;
  goals?: LocalizedString[];
  researchers: Researcher[];
}